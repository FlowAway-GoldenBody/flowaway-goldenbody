//browser global vars
window.browserGlobals = window.browserGlobals || {};
window.browserGlobals.nhjd = 1;
window.browserGlobals.tmp = {};
window.browserGlobals.vfsScriptPath =
  "/systemfiles/runtime/apps/browser/asset/fileSystemRelatedStuff.js";
window.browserGlobals.frontendFilePickerStuffJSPath =
  "/systemfiles/runtime/apps/browser/asset/frontendFilePickerStuff.js";
window.browserGlobals.iframePatchPath =
  "/systemfiles/runtime/apps/browser/asset/iframeRewrites.js";
window.browserGlobals.browserhelperPath =
  "/systemfiles/runtime/apps/browser/asset/browserhelper.js";
window.browserGlobals.pid = '';
window.browserGlobals.fetchId = async function () {
  if (window.protectedGlobals.statusData.wifiEnabled) {
    window.browserGlobals.id = await window.protectedGlobals.ReadFile(window.browserGlobals.profileUserIdPath, { text: true, direct: true }).then(res => res ? res.trim() : "").catch(() => "");
  }
};
window.addEventListener("wifi-toggle", (e) => {
  let enabled = e.detail.enabled;
  if (!enabled) {
    window.browserGlobals.pid = window.browserGlobals.id;
    window.browserGlobals.id = "";
  } else {
    window.browserGlobals.id = window.browserGlobals.pid;
  }
});
// this need async fn idk y
(async () => {
  window.browserGlobals.vfstxt = await window.protectedGlobals
    .ReadFile(window.browserGlobals.vfsScriptPath, { text: true, direct: true })
    .then((res) => (res ? res : ""))
    .catch((e) => "");
  window.browserGlobals.frontendFilePickerStuffJS =
    await window.protectedGlobals
      .ReadFile(window.browserGlobals.frontendFilePickerStuffJSPath, {
        text: true,
        direct: true,
      })
      .then((res) => (res ? res : ""))
      .catch((e) => "");
  window.browserGlobals.iframePatch = await window.protectedGlobals
    .ReadFile(window.browserGlobals.iframePatchPath, { text: true, direct: true })
    .then((res) => (res ? res : ""))
    .catch((e) => "");
  window.browserGlobals.browserhelper = await window.protectedGlobals
    .ReadFile(window.browserGlobals.browserhelperPath, { text: true, direct: true })
    .then((res) => {
      eval(res || "");
    })
    .catch((e) => "");
  window.browserGlobals.indexedDBhelper = await window.protectedGlobals
    .ReadFile("/systemfiles/runtime/apps/browser/asset/browserhelper-indexedDB.js", { text: true, direct: true })
    .then((res) => {
      eval(res || "");
    });
  window.browserGlobals.indexedDBPatch = await window.protectedGlobals
    .ReadFile("/systemfiles/runtime/apps/browser/asset/indexedDB.js", { text: true, direct: true });
})();
window.browserGlobals.findWindowById = function(id) {
  // Implementation for finding window by ID
  window.browserGlobals.allBrowsers.forEach(b => {
    if (b.rootElement._goldenbodyId === id) {
      return b;
    }
  });
};
window.browser = async function (
  preloadlink = null,
  preloadsize = 100,
  posX = 20,
  posY = 20,
  preMaximized = false,
) {
    if (posX == 20 && posY == 20) {
      let pos = window.protectedGlobals.getNextWindowXY();
      posX = pos.x;
      posY = pos.y;
    }
    let assignedId = window.browserGlobals.allocateBrowserGoldenbodyId();
    let getRoot = () => {};
    let exposedToTabs = {};
    let checkerinterval = null;
    let activatedUserscriptNames = [];
    let curProfileName = 'profile';
    let stopIframePatchWatcher = null;
    let getCurProfileName = function() { return curProfileName; };
    window.browserGlobals.getCurProfileName = getCurProfileName;

    // initialize curProfileName from defaultprofile.txt if present
    async function initDefaultProfile() {
      try {
        const defPath = "/systemfiles/runtime/apps/browser/defaultprofile.txt";
        try {
          const v = await window.protectedGlobals.ReadFile(defPath, { text: true, direct: true }).catch(() => null);
          if (v && typeof v === 'string' && v.trim()) {
            curProfileName = v.trim();
          }
        } catch (e) {
          // read failed or file missing — ignore
        }
        // initialize window.browserGlobals profile paths and load profile
        try {
          window.browserGlobals.profileUserIdPath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "userID.txt";
          window.browserGlobals.profileSettingsPath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "settings.json";
          if (window.browserGlobals.readBrowserProfile) {
            const prof = await window.browserGlobals.readBrowserProfile();
            window.browserGlobals.profile = prof;
            window.browserGlobals.profileState.siteSettings = prof.siteSettings || [];
            window.browserGlobals.profileState.enableURLSync = !!prof.enableURLSync;
            window.browserGlobals.profileState.lazyloading = !!prof.lazyloading;
            window.browserGlobals.profileState.siteZoom = prof.siteZoom || {};
            await populateActivatedUserscripts();
          }
        } catch (e) {}
      } catch (e) {}
    }
    await initDefaultProfile();
    window.browserGlobals.cookiesPath =
    "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "localstorage/cookies.json";
    window.browserGlobals.localStoragePath =
    "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "localstorage/localstorage.json";
    async function initStores() {
      const newCookies = await window.protectedGlobals.ReadFile(window.browserGlobals.cookiesPath, { text: true, direct: true }).then(res => res ? JSON.parse(res) : {}).catch(() => ({}));
      window.browserGlobals.mutateObject(window.browserGlobals.cookies, newCookies);
      const newLocalStorage = await window.protectedGlobals.ReadFile(window.browserGlobals.localStoragePath, { text: true, direct: true }).then(res => res ? JSON.parse(res) : {}).catch(() => ({}));
      window.browserGlobals.mutateObject(window.browserGlobals.localStorageStore, newLocalStorage);
      window.browserGlobals.id = await window.protectedGlobals.ReadFile(window.browserGlobals.profileUserIdPath, { text: true, direct: true }).then(res => res ? res.trim() : "").catch(() => "");
    }
    initStores();

    // populate activatedUserscriptNames at startup
    async function populateActivatedUserscripts() {
      const basePath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "userscripts";
      try {
        let entries = [];
        try {
          entries = (await window.protectedGlobals.ReadFolder(basePath).catch(() => [])) || [];
        } catch (e) {
          // try to create folder if read failed
          try { await window.protectedGlobals.WriteFolder(basePath).catch(() => {}); } catch (e) {}
          entries = (await window.protectedGlobals.ReadFolder(basePath).catch(() => [])) || [];
        }
        for (const entry of entries) {
          try {
            const activePath = basePath + "/" + entry + "/active.txt";
            let av = null;
            try {
              av = await window.protectedGlobals.ReadFile(activePath, { text: true, direct: true }).catch(() => null);
            } catch (e) { av = null; }
            const val = (av && typeof av === "string" ? av.trim().toLowerCase() : "");
            if (/^t/.test(val)) {
              activatedUserscriptNames.push(entry);
            }
          } catch (e) {}
        }
      } catch (e) {}
    };
    populateActivatedUserscripts();
setTimeout(() => {
  function checkFrames(root = document) {
    // add something so the interval knows when to clear itself
    if (!root?.querySelectorAll) return;
    try {
    if (!getRoot().isConnected) {clearInterval(checkerinterval); return;}
    } catch (e) { clearInterval(checkerinterval); return; }
    for (const frame of root.querySelectorAll("iframe")) {
      try {
        const doc = frame.contentDocument || frame.contentWindow?.document;
        if (!doc) continue;

        if (!doc.__gbCookieHookInstalled) {
          let recurseFunc = null;
          let t = document.querySelectorAll(".sim-iframe");
          // Find which top-level tab iframe (direct child of root in the main window) contains this iframe
          for (let topFrame of t) {
            // Try to check if this frame is inside topFrame by walking the tree
            topFrame = topFrame.contentWindow;
            try {
              let current = frame.contentWindow;
              while (current) {
                if (current === topFrame) {
                  recurseFunc = topFrame.__gbframeElement.__gbRecurseFrames;
                  break;
                }
                // Try to get parent from contentWindow
                current = current?.parent;
                if (current === window) break; // reached top without finding topFrame, stop searching
              }
              if (recurseFunc) break;
            } catch (e) {}
          }
          
          if (recurseFunc) {
            recurseFunc(doc, null, frame);
          }
          continue;
        }

        checkFrames(doc);
      } catch {}
    }

    for (const host of root.querySelectorAll("*")) {
      try {
        if (host.shadowRoot) {
          checkFrames(host.shadowRoot);
        }
      } catch {}
    }
  }

  checkerinterval = setInterval(checkFrames, 3000);
}, 5000);
    function showSetSpeedDialogue(anchorPoint = null) {
      document.getElementById("set-speed-ui")?.remove();

      const panel = document.createElement("div");
      panel.id = "set-speed-ui";
      panel.className = "panel";
      panel.classList.toggle("dark", window.browserGlobals.dark);
      panel.classList.toggle("light", !window.browserGlobals.dark);
      panel.style.cssText =
        "position:fixed;z-index:999999;width:360px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

      let closed = false;

      function cleanup() {
        if (closed) return;
        closed = true;
        try {
          panel.remove();
        } catch (e) {}
        try {
          document.removeEventListener("pointerdown", onOutsidePointerDown, true);
        } catch (e) {}
        try {
          document.removeEventListener("pointermove", onPointerMove);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUp);
        } catch (e) {}
      }

      function onOutsidePointerDown(event) {
        if (!panel.contains(event.target)) cleanup();
      }

      const title = document.createElement("div");
      title.style.cssText = "font-weight:600;margin-bottom:8px;cursor:grab";
      title.textContent = "Change RAF Speed";
      panel.appendChild(title);

      const desc = document.createElement("div");
      desc.style.cssText = "font-size:12px;color:#888;margin-bottom:8px";
      desc.textContent = "Adjust animation speed for most games";
      panel.appendChild(desc);

      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:8px;";

      const range = document.createElement("input");
      range.type = "range";
      range.min = "0.1";
      range.max = "100";
      range.step = "0.1";
      range.value = activatedTab.RAFSpeed || '1';
      range.style.cssText = "flex:1";

      const num = document.createElement("input");
      num.type = "number";
      num.min = 0.1;
      num.max = 100;
      num.value = range.value;
      num.style.cssText = "width:64px;padding:6px;border-radius:6px;border:1px solid #ccc";

      range.addEventListener("input", () => {
        num.value = range.value;
      });
      num.addEventListener("input", () => {
        let v = Number(num.value) || 0;
        if (v < 0.1) v = 0.1;
        if (v > 100) v = 100;
        range.value = String(v);
        num.value = String(v);
      });

      row.appendChild(range);
      row.appendChild(num);
      panel.appendChild(row);

      const hint = document.createElement("div");
      hint.style.cssText = "font-size:12px;color:#666;margin-top:8px";
      hint.textContent = "1 = normal speed. Lower = slower, higher = faster.";
      panel.appendChild(hint);

      const btnRow = document.createElement("div");
      btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px;margin-top:12px";
      const btnCancel = document.createElement("button");
      btnCancel.textContent = "Cancel";
      btnCancel.onclick = () => cleanup();
      const btnApply = document.createElement("button");
      btnApply.textContent = "Apply";
      btnApply.style.background = "#4c8bf5";
      btnApply.style.color = "#fff";
      btnApply.onclick = async () => {
        const speed = Number(range.value) || 1;
        try {
          activatedTab.setRAFSpeed(speed)
        } catch (e) {}
        cleanup();
      };
      btnRow.appendChild(btnCancel);
      btnRow.appendChild(btnApply);
      panel.appendChild(btnRow);

      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let origLeft = 0;
      let origTop = 0;
      function onPointerMove(e) {
        if (!isDragging) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        panel.style.left = origLeft + dx + "px";
        panel.style.top = origTop + dy + "px";
        panel.style.transform = "";
      }
      function onPointerUp() {
        if (!isDragging) return;
        isDragging = false;
        title.style.cursor = "grab";
        try {
          document.removeEventListener("pointermove", onPointerMove);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUp);
        } catch (e) {}
      }
      title.addEventListener("pointerdown", (ev) => {
        ev.preventDefault();
        isDragging = true;
        startX = ev.clientX;
        startY = ev.clientY;
        const r = panel.getBoundingClientRect();
        origLeft = r.left;
        origTop = r.top;
        title.style.cursor = "grabbing";
        document.addEventListener("pointermove", onPointerMove);
        document.addEventListener("pointerup", onPointerUp);
      });

      document.body.appendChild(panel);

      setTimeout(() => {
        if (!closed) {
          document.addEventListener("pointerdown", onOutsidePointerDown, true);
        }
      }, 0);

      if (
        anchorPoint &&
        typeof anchorPoint.x === "number" &&
        typeof anchorPoint.y === "number"
      ) {
        const rect = panel.getBoundingClientRect();
        const viewportW = window.innerWidth || document.documentElement.clientWidth || 0;
        const viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
        let left = anchorPoint.x - rect.width;
        let top = anchorPoint.y;
        left = Math.max(0, Math.min(left, Math.max(0, viewportW - rect.width)));
        top = Math.max(0, Math.min(top, Math.max(0, viewportH - rect.height)));
        panel.style.left = left + "px";
        panel.style.top = top + "px";
        panel.style.transform = "";
      } else {
        panel.style.left = "50%";
        panel.style.top = "50%";
        panel.style.transform = "translate(-50%,-50%)";
      }
    }
  function showConfirmDialog(title, message) {
    return new Promise((resolve) => {
      document.getElementById("confirm-dialog")?.remove();

      const dialog = document.createElement("div");
      dialog.id = "confirm-dialog";
      dialog.className = "panel";
      dialog.classList.toggle("dark", window.browserGlobals.dark);
      dialog.classList.toggle("light", !window.browserGlobals.dark);
      dialog.style.cssText =
        "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:999999;width:380px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:20px;font-family:system-ui;font-size:14px;";

      let resolved = false;
      function closeConfirmDialog(result) {
        if (resolved) return;
        resolved = true;
        try {
          document.removeEventListener(
            "pointerdown",
            onOutsidePointerDown,
            true,
          );
        } catch (e) {}
        try {
          document.removeEventListener("keydown", onEscKeyDown, true);
        } catch (e) {}
        dialog.remove();
        resolve(result);
      }

      function onOutsidePointerDown(event) {
        if (!dialog.contains(event.target)) {
          closeConfirmDialog(false);
        }
      }

      function onEscKeyDown(event) {
        if (event.key === "Escape") {
          event.preventDefault();
          closeConfirmDialog(false);
        }
      }

      const titleEl = document.createElement("div");
      titleEl.style.cssText =
        "font-weight:600;margin-bottom:12px;font-size:16px;";
      titleEl.textContent = title;
      dialog.appendChild(titleEl);

      const msgEl = document.createElement("div");
      msgEl.style.cssText = `font-size:14px;color:#${window.browserGlobals.dark ? "ccc" : "666"};margin-bottom:20px;line-height:1.5;`;
      msgEl.textContent = message;
      dialog.appendChild(msgEl);

      const btnRow = document.createElement("div");
      btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px;";

      const btnCancel = document.createElement("button");
      btnCancel.textContent = "Cancel";
      btnCancel.style.cssText =
        "padding:8px 16px;border-radius:6px;border:1px solid #ccc;background:#f5f5f5;cursor:pointer;font-size:14px;";
      btnCancel.onmouseenter = () => (btnCancel.style.background = "#e8e8e8");
      btnCancel.onmouseleave = () => (btnCancel.style.background = "#f5f5f5");
      btnCancel.onclick = () => closeConfirmDialog(false);

      const btnConfirm = document.createElement("button");
      btnConfirm.textContent = "Continue";
      btnConfirm.style.cssText =
        "padding:8px 16px;border-radius:6px;border:none;background:#4c8bf5;color:#fff;cursor:pointer;font-size:14px;";
      btnConfirm.onmouseenter = () => (btnConfirm.style.background = "#3a75d4");
      btnConfirm.onmouseleave = () => (btnConfirm.style.background = "#4c8bf5");
      btnConfirm.onclick = () => closeConfirmDialog(true);

      btnRow.appendChild(btnCancel);
      btnRow.appendChild(btnConfirm);
      dialog.appendChild(btnRow);

      document.body.appendChild(dialog);

      setTimeout(() => {
        if (!resolved) {
          document.addEventListener("pointerdown", onOutsidePointerDown, true);
          document.addEventListener("keydown", onEscKeyDown, true);
        }
      }, 0);

      btnConfirm.focus();
    });
  }
  function normalizePreloadLink(value) {
    const input = String(value || "").trim();
    if (!input) return "";
    if (
      input.startsWith("file://") ||
      input.startsWith("http://") ||
      input.startsWith("https://") ||
      input.startsWith("goldenbody://") ||
      input.startsWith("javascript:")
    ) {
      return input;
    }
    if (
      input.startsWith("root/") ||
      input.startsWith("/") ||
      input.startsWith("./") ||
      input.startsWith("../") ||
      /[\\/]/.test(input) ||
      /\.[a-z0-9]{1,10}([?#].*)?$/i.test(input)
    ) {
      return `file://${input.replace(/^\/+/, "")}`;
    }
    return input;
  }


  async function showUserscriptDialogue() {
    document.getElementById("userscript-dialog")?.remove();

    const panel = document.createElement("div");
    panel.id = "userscript-dialog";
    panel.className = "panel";
    panel.classList.toggle("dark", window.browserGlobals.dark);
    panel.classList.toggle("light", !window.browserGlobals.dark);
    panel.style.cssText =
      "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:999999;width:480px;max-height:70vh;overflow:auto;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

    const title = document.createElement("div");
    title.style.cssText = "font-weight:600;margin-bottom:8px;";
    title.textContent = "User Scripts";
    panel.appendChild(title);

    const desc = document.createElement("div");
    desc.style.cssText = "font-size:12px;color:#888;margin-bottom:12px";
    desc.textContent = "Enable or disable userscripts in your profile.";
    panel.appendChild(desc);

    const addBtn = document.createElement("button");
    addBtn.textContent = "Add userscript";
    addBtn.style.cssText = "margin-bottom:12px;background:#4c8bf5;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;";
    addBtn.onclick = async () => {
      const data = await (async function showAddUserscriptDialog() {
        return new Promise((resolve) => {
          document.getElementById("add-userscript-dialog")?.remove();
          const dlg = document.createElement("div");
          dlg.id = "add-userscript-dialog";
          dlg.className = "panel";
          dlg.classList.toggle("dark", window.browserGlobals.dark);
          dlg.classList.toggle("light", !window.browserGlobals.dark);
          dlg.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1000000;width:420px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

          const t = document.createElement("div");
          t.style.cssText = "font-weight:600;margin-bottom:8px";
          t.textContent = "Create Userscript";
          dlg.appendChild(t);

          const nameLabel = document.createElement("div");
          nameLabel.style.cssText = "font-size:12px;margin-bottom:6px";
          nameLabel.textContent = "Name";
          dlg.appendChild(nameLabel);
          const nameInput = document.createElement("input");
          nameInput.style.cssText = "width:100%;padding:8px;margin-bottom:8px;border-radius:6px;border:1px solid #ccc";
          dlg.appendChild(nameInput);

          const scriptLabel = document.createElement("div");
          scriptLabel.style.cssText = "font-size:12px;margin-bottom:6px";
          scriptLabel.textContent = "Script content";
          dlg.appendChild(scriptLabel);
          const scriptArea = document.createElement("textarea");
          scriptArea.style.cssText = "width:100%;height:160px;padding:8px;border-radius:6px;border:1px solid #ccc;margin-bottom:8px;font-family:monospace;font-size:12px;";
          dlg.appendChild(scriptArea);

          const btnRow = document.createElement("div");
          btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px";
          const btnCancel = document.createElement("button");
          btnCancel.textContent = "Cancel";
          btnCancel.onclick = () => { dlg.remove(); resolve(null); };
          const btnCreate = document.createElement("button");
          btnCreate.textContent = "Create";
          btnCreate.style.cssText = "background:#4c8bf5;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;";
          btnCreate.onclick = () => {
            const name = String(nameInput.value || "").trim();
            const script = String(scriptArea.value || "");
            if (!name) return window.protectedGlobals.notification && window.protectedGlobals.notification("Name required");
            dlg.remove();
            resolve({ name, script });
          };
          btnRow.appendChild(btnCancel);
          btnRow.appendChild(btnCreate);
          dlg.appendChild(btnRow);
          document.body.appendChild(dlg);
        });
      })();

      if (data && data.name) {
        const safeFolder = data.name.replace(/[\\/\0]/g, "-").replace(/[^a-zA-Z0-9_\- \(\)]/g, "-");
        const folderPath = basePath + "/" + safeFolder;
        try {
          // check by attempting to read; if read succeeds, folder exists
          let already = false;
          try {
            const sub = await window.protectedGlobals.ReadFolder(folderPath).catch(() => null);
            if (sub && Array.isArray(sub)) already = true;
          } catch (e) { already = false; }
          if (already) {
            window.protectedGlobals.notification && window.protectedGlobals.notification("Folder already exists");
            return;
          }
          await window.protectedGlobals.WriteFolder(folderPath).catch(() => {});
          await window.protectedGlobals.WriteFile(folderPath + "/script.txt", btoa(data.script || ""));
          await window.protectedGlobals.WriteFile(folderPath + "/name.txt", btoa(data.name));
          await window.protectedGlobals.WriteFile(folderPath + "/active.txt", btoa("true"));
          // mark as activated in memory
          if (activatedUserscriptNames.indexOf(safeFolder) === -1) activatedUserscriptNames.push(safeFolder);
          window.protectedGlobals.notification && window.protectedGlobals.notification("Created");
          panel.remove();
          showUserscriptDialogue();
        } catch (e) {
          window.protectedGlobals.notification && window.protectedGlobals.notification("Error creating userscript");
        }
      }
    };
    panel.appendChild(addBtn);

    const list = document.createElement("div");
    panel.appendChild(list);

    const basePath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "userscripts";

    try {
      try {
        await window.protectedGlobals.ReadFolder(basePath).catch(() => []);
      } catch (e) {
        try { await window.protectedGlobals.WriteFolder(basePath).catch(() => {}); } catch (e) {}
      }
    } catch (e) {}

    let entries = [];
    try {
      entries = (await window.protectedGlobals.ReadFolder(basePath).catch(() => [])) || [];
    } catch (e) {
      entries = [];
    }

    if (!entries.length) {
      const empty = document.createElement("div");
      empty.style.cssText = "color:#666;padding:8px 0;";
      empty.textContent = "No userscripts found. Put script folders in " + basePath;
      list.appendChild(empty);
    } else {
      for (const entry of entries) {
        // ensure it's a folder by attempting to read it
        let sub;
        try {
          sub = await window.protectedGlobals.ReadFolder(basePath + "/" + entry);
        } catch (e) {
          sub = null;
        }
        if (!sub) continue;

        const row = document.createElement("div");
        row.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(0,0,0,0.06);";

        const left = document.createElement("div");
        left.style.cssText = "display:flex;flex-direction:column;min-width:0;";

        const scriptName = document.createElement("div");
        scriptName.style.cssText = "font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
        // try to read name.txt
        try {
          const nv = await window.protectedGlobals.ReadFile(basePath + "/" + entry + "/name.txt", { text: true, direct: true }).catch(() => null);
          let nameVal = nv && typeof nv === "string" ? nv.trim() : entry;
          scriptName.textContent = nameVal || entry;
        } catch (e) {
          scriptName.textContent = entry;
        }
        left.appendChild(scriptName);

        const hint = document.createElement("div");
        hint.style.cssText = "font-size:12px;color:#666;";
        hint.textContent = entry;
        left.appendChild(hint);

        row.appendChild(left);

        const toggleWrap = document.createElement("div");
        toggleWrap.style.cssText = "display:flex;align-items:center;gap:8px";
        const toggle = document.createElement("input");
        toggle.type = "checkbox";
        toggle.style.cssText = "width:18px;height:18px";

        // ensure active.txt exists and read its value
        try {
          const activePath = basePath + "/" + entry + "/active.txt";
          let av = null;
          try {
            av = await window.protectedGlobals.ReadFile(activePath, { text: true, direct: true }).catch(() => null);
            if (!av) {
              await window.protectedGlobals.WriteFile(activePath, btoa("true")).catch(() => {});
              toggle.checked = true;
            } else {
              let val = av && typeof av === "string" ? av.trim().toLowerCase() : "true";
              toggle.checked = /^t/.test(val) ? true : false;
            }
          } catch (e) {
            // read failed; try create
            try { await window.protectedGlobals.WriteFile(activePath, btoa("true")).catch(() => {}); } catch (e) {}
            toggle.checked = true;
          }
        } catch (e) {
          toggle.checked = true;
        }

        
        toggle.addEventListener("change", async () => {
          try {
            const activePath = basePath + "/" + entry + "/active.txt";
            await window.protectedGlobals.WriteFile(activePath, toggle.checked ? btoa("true") : btoa("false"));
            // update activatedUserscriptNames
            const idx = activatedUserscriptNames.indexOf(entry);
            if (toggle.checked) {
              if (idx === -1) activatedUserscriptNames.push(entry);
            } else {
              if (idx !== -1) activatedUserscriptNames.splice(idx, 1);
            }
            try { window.protectedGlobals.notification && window.protectedGlobals.notification("Saved"); } catch (e) {}
          } catch (e) {
            try { window.protectedGlobals.notification && window.protectedGlobals.notification("Error saving active state"); } catch (er) {}
          }
        });

        toggleWrap.appendChild(toggle);
        // delete button
        const delBtn = document.createElement("button");
        delBtn.textContent = "Delete";
        delBtn.style.cssText = "background:#d94c4c;color:#fff;border:none;padding:6px 8px;border-radius:6px;cursor:pointer;";
        // edit button
        const editBtn = document.createElement("button");
        editBtn.textContent = "Edit";
        editBtn.style.cssText = "background:#4c8bf5;color:#fff;border:none;padding:6px 8px;border-radius:6px;cursor:pointer;";
        editBtn.onclick = async () => {
          // read existing values
          const folderPath = basePath + "/" + entry;
          let curName = entry;
          let curScript = "";
          try {
            const nv = await window.protectedGlobals.ReadFile(folderPath + "/name.txt", { text: true, direct: true }).catch(() => null);
            if (nv && typeof nv === "string") curName = nv.trim();
          } catch (e) {}
          try {
            const sv = await window.protectedGlobals.ReadFile(folderPath + "/script.txt", { text: true, direct: true }).catch(() => null);
            if (sv && typeof sv === "string") curScript = sv;
          } catch (e) {}

          // show edit dialog (same UI as create)
          const data = await (async function showEditUserscriptDialog(name, script) {
            return new Promise((resolve) => {
              document.getElementById("edit-userscript-dialog")?.remove();
              const dlg = document.createElement("div");
              dlg.id = "edit-userscript-dialog";
              dlg.className = "panel";
              dlg.classList.toggle("dark", window.browserGlobals.dark);
              dlg.classList.toggle("light", !window.browserGlobals.dark);
              dlg.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1000000;width:420px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

              const t = document.createElement("div");
              t.style.cssText = "font-weight:600;margin-bottom:8px";
              t.textContent = "Edit Userscript";
              dlg.appendChild(t);

              const nameLabel = document.createElement("div");
              nameLabel.style.cssText = "font-size:12px;margin-bottom:6px";
              nameLabel.textContent = "Name";
              dlg.appendChild(nameLabel);
              const nameInput = document.createElement("input");
              nameInput.style.cssText = "width:100%;padding:8px;margin-bottom:8px;border-radius:6px;border:1px solid #ccc";
              nameInput.value = name || "";
              dlg.appendChild(nameInput);

              const scriptLabel = document.createElement("div");
              scriptLabel.style.cssText = "font-size:12px;margin-bottom:6px";
              scriptLabel.textContent = "Script content";
              dlg.appendChild(scriptLabel);
              const scriptArea = document.createElement("textarea");
              scriptArea.style.cssText = "width:100%;height:160px;padding:8px;border-radius:6px;border:1px solid #ccc;margin-bottom:8px;font-family:monospace;font-size:12px;";
              scriptArea.value = script || "";
              dlg.appendChild(scriptArea);

              const btnRow = document.createElement("div");
              btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px";
              const btnCancel = document.createElement("button");
              btnCancel.textContent = "Cancel";
              btnCancel.onclick = () => { dlg.remove(); resolve(null); };
              const btnSave = document.createElement("button");
              btnSave.textContent = "Save";
              btnSave.style.cssText = "background:#4c8bf5;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;";
              btnSave.onclick = () => {
                const name = String(nameInput.value || "").trim();
                const script = String(scriptArea.value || "");
                if (!name) return window.protectedGlobals.notification && window.protectedGlobals.notification("Name required");
                dlg.remove();
                resolve({ name, script });
              };
              btnRow.appendChild(btnCancel);
              btnRow.appendChild(btnSave);
              dlg.appendChild(btnRow);
              document.body.appendChild(dlg);
            });
          })(curName, curScript);

          if (data && data.name) {
            try {
              await window.protectedGlobals.WriteFile(folderPath + "/script.txt", btoa(data.script || ""));
              await window.protectedGlobals.WriteFile(folderPath + "/name.txt", btoa(data.name));
              window.protectedGlobals.notification && window.protectedGlobals.notification("Saved");
              panel.remove();
              showUserscriptDialogue();
            } catch (e) {
              window.protectedGlobals.notification && window.protectedGlobals.notification("Error saving userscript");
            }
          }
        };
        delBtn.onclick = async () => {
          const ok = await showConfirmDialog("Delete userscript", `Delete userscript '${entry}'? This cannot be undone.`);
          if (!ok) return;
          try {
            await window.protectedGlobals.DeleteFile(basePath + "/" + entry);
            // remove from activated list
            const di = activatedUserscriptNames.indexOf(entry);
            if (di !== -1) activatedUserscriptNames.splice(di, 1);
            window.protectedGlobals.notification && window.protectedGlobals.notification("Deleted");
            panel.remove();
            showUserscriptDialogue();
          } catch (e) {
            window.protectedGlobals.notification && window.protectedGlobals.notification("Error deleting userscript");
          }
        };

        toggleWrap.appendChild(editBtn);
        toggleWrap.appendChild(delBtn);
        row.appendChild(toggleWrap);

        list.appendChild(row);
      }
    }

    const btnRow = document.createElement("div");
    btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px;margin-top:12px;";
    const btnClose = document.createElement("button");
    btnClose.textContent = "Close";
    btnClose.onclick = () => panel.remove();
    btnRow.appendChild(btnClose);
    panel.appendChild(btnRow);

    document.body.appendChild(panel);
  }

  async function showProfileDialogue() {
    document.getElementById("profile-dialog")?.remove();

    const panel = document.createElement("div");
    panel.id = "profile-dialog";
    panel.className = "panel";
    panel.classList.toggle("dark", window.browserGlobals.dark);
    panel.classList.toggle("light", !window.browserGlobals.dark);
    panel.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:999999;width:480px;max-height:70vh;overflow:auto;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

    const title = document.createElement("div");
    title.style.cssText = "font-weight:600;margin-bottom:8px;";
    title.textContent = "Browser Profiles";
    panel.appendChild(title);

    const desc = document.createElement("div");
    desc.style.cssText = "font-size:12px;color:#888;margin-bottom:12px";
    desc.textContent = "Switch between browser profiles or create a new one.";
    panel.appendChild(desc);

    const addBtn = document.createElement("button");
    addBtn.textContent = "Add browser profile";
    addBtn.style.cssText = "margin-bottom:12px;background:#4c8bf5;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;";
    addBtn.onclick = async () => {
      const data = await (async function showAddProfileDialog() {
        return new Promise((resolve) => {
          document.getElementById("add-profile-dialog")?.remove();
          const dlg = document.createElement("div");
          dlg.id = "add-profile-dialog";
          dlg.className = "panel";
          dlg.classList.toggle("dark", window.browserGlobals.dark);
          dlg.classList.toggle("light", !window.browserGlobals.dark);
          dlg.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1000000;width:360px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

          const t = document.createElement("div");
          t.style.cssText = "font-weight:600;margin-bottom:8px";
          t.textContent = "Create Browser Profile";
          dlg.appendChild(t);

          const nameLabel = document.createElement("div");
          nameLabel.style.cssText = "font-size:12px;margin-bottom:6px";
          nameLabel.textContent = "Profile name";
          dlg.appendChild(nameLabel);
          const nameInput = document.createElement("input");
          nameInput.style.cssText = "width:100%;padding:8px;margin-bottom:8px;border-radius:6px;border:1px solid #ccc";
          dlg.appendChild(nameInput);

          const btnRow = document.createElement("div");
          btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px";
          const btnCancel = document.createElement("button");
          btnCancel.textContent = "Cancel";
          btnCancel.onclick = () => { dlg.remove(); resolve(null); };
          const btnCreate = document.createElement("button");
          btnCreate.textContent = "Create";
          btnCreate.style.cssText = "background:#4c8bf5;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;";
          btnCreate.onclick = () => {
            const name = String(nameInput.value || "").trim();
            if (!name) return window.protectedGlobals.notification && window.protectedGlobals.notification("Name required");
            dlg.remove();
            resolve({ name });
          };
          btnRow.appendChild(btnCancel);
          btnRow.appendChild(btnCreate);
          dlg.appendChild(btnRow);
          document.body.appendChild(dlg);
        });
      })();

      if (data && data.name) {
        const safeName = data.name.replace(/[\\/\0]/g, "-").replace(/[^a-zA-Z0-9_\- \(\)]/g, "-");
        const folderPath = "/systemfiles/runtime/apps/browser" + "/" + safeName;
        const listPath = "/systemfiles/runtime/apps/browser/profilepaths.txt";
        try {
          // ensure the folder exists: attempt to read, create if missing
          try {
            const sub = await window.protectedGlobals.ReadFolder(folderPath).catch(() => null);
            if (!sub) {
              await window.protectedGlobals.WriteFolder(folderPath).catch(() => {});
            }
          } catch (e) {
            try { await window.protectedGlobals.WriteFolder(folderPath).catch(() => {}); } catch (e) {}
          }
          // initialize default profile files (settings, userID, localstorage)
          try {
            const defaultProfile =
              window.browserGlobals && window.browserGlobals.defaultBrowserProfile
                ? window.browserGlobals.defaultBrowserProfile()
                : {};
            const settingsPayload = JSON.stringify(defaultProfile, null, 2);
            await window.protectedGlobals.WriteFile(folderPath + "/settings.json", btoa(settingsPayload)).catch(() => {});
            await window.protectedGlobals.WriteFile(folderPath + "/userID.txt", btoa("")).catch(() => {});
            try { await window.protectedGlobals.WriteFolder(folderPath + "/localstorage").catch(() => {}); } catch (e) {}
            await window.protectedGlobals.WriteFile(folderPath + "/localstorage/cookies.json", btoa("{}")).catch(() => {});
            await window.protectedGlobals.WriteFile(folderPath + "/localstorage/localstorage.json", btoa("{}")).catch(() => {});
          } catch (e) {}
          // ensure profilepaths.txt exists and load content
          let content = "";
          try {
            content = await window.protectedGlobals.ReadFile(listPath, { text: true, direct: true }).catch(() => "") || "";
          } catch (e) { content = ""; }
          if (!content) content = "profile";
          const lines = content.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
          if (lines.indexOf(safeName) === -1) lines.push(safeName);
          await window.protectedGlobals.WriteFile(listPath, btoa(lines.join("\n")));
          window.protectedGlobals.notification && window.protectedGlobals.notification("Profile created");
          panel.remove();
          showProfileDialogue();
        } catch (e) {
          window.protectedGlobals.notification && window.protectedGlobals.notification("Error creating profile");
        }
      }
    };
    panel.appendChild(addBtn);

    const list = document.createElement("div");
    panel.appendChild(list);

    const listPath = "/systemfiles/runtime/apps/browser/profilepaths.txt";
    const defaultPath = "/systemfiles/runtime/apps/browser/defaultprofile.txt";

    try {
      // ensure list exists by attempting to read; if missing, write a default
      let rawTry = "";
      try {
        rawTry = (await window.protectedGlobals.ReadFile(listPath, { text: true, direct: true }).catch(() => "")) || "";
      } catch (e) { rawTry = ""; }
      if (!rawTry) {
        try { await window.protectedGlobals.WriteFile(listPath, btoa("profile")).catch(() => {}); } catch (e) {}
        rawTry = "profile";
      }
      var raw = rawTry;
    } catch (e) {
      var raw = "";
    }

    const lines = raw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);

    let defVal = null;
    try {
      try {
        defVal = await window.protectedGlobals.ReadFile(defaultPath, { text: true, direct: true }).catch(() => null) || null;
        if (defVal && typeof defVal === 'string') defVal = defVal.trim();
      } catch (e) { defVal = null; }
    } catch (e) { defVal = null; }

    if (!lines.length) {
      const empty = document.createElement("div");
      empty.style.cssText = "color:#666;padding:8px 0;";
      empty.textContent = "No profiles defined. Add one to get started.";
      list.appendChild(empty);
    } else {
      for (const p of lines) {
        const row = document.createElement("div");
        row.style.cssText = "display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(0,0,0,0.06);";
        const left = document.createElement("div");
        left.style.cssText = "display:flex;flex-direction:column;min-width:0;";
        const nameEl = document.createElement("div");
        nameEl.style.cssText = "font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
        nameEl.textContent = p;
        left.appendChild(nameEl);
        const hint = document.createElement("div");
        hint.style.cssText = "font-size:12px;color:#666;";
        hint.textContent = "/systemfiles/runtime/apps/browser/" + p;
        left.appendChild(hint);
        row.appendChild(left);

        const right = document.createElement("div");
        right.style.cssText = "display:flex;align-items:center;gap:8px";

        const switchBtn = document.createElement("button");
        switchBtn.textContent = "Switch";
        switchBtn.style.cssText = "background:#4c8bf5;color:#fff;border:none;padding:6px 8px;border-radius:6px;cursor:pointer;";
        switchBtn.onclick = async () => {
          curProfileName = p;
          // update profile paths used by browserhelper
          try {
            window.browserGlobals.profileUserIdPath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "userID.txt";
            window.browserGlobals.profileSettingsPath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "settings.json";
            // load profile into memory (does not reload tabs)
            if (window.browserGlobals.readBrowserProfile) {
              const prof = await window.browserGlobals.readBrowserProfile();
              window.browserGlobals.profile = prof;
              // sync profileState
              window.browserGlobals.profileState.siteSettings = prof.siteSettings || [];
              window.browserGlobals.profileState.enableURLSync = !!prof.enableURLSync;
              window.browserGlobals.profileState.lazyloading = !!prof.lazyloading;
              window.browserGlobals.profileState.siteZoom = prof.siteZoom || {};
              await populateActivatedUserscripts();
            }
            // refresh local paths and reload in-memory stores
            try {
              window.browserGlobals.cookiesPath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "localstorage/cookies.json";
              window.browserGlobals.localStoragePath = "/systemfiles/runtime/apps/browser" + "/" + getCurProfileName() + "/" + "localstorage/localstorage.json";
              window.browserGlobals.updateIndexedDbStore(getCurProfileName());
              // reload stores by mutating them in-place so all tabs see the same references
              const newCookies = await window.protectedGlobals.ReadFile(window.browserGlobals.cookiesPath, { text: true, direct: true }).then(res => res ? JSON.parse(res) : {}).catch(() => ({}));
              window.browserGlobals.mutateObject(window.browserGlobals.cookies, newCookies);
              const newLocalStorage = await window.protectedGlobals.ReadFile(window.browserGlobals.localStoragePath, { text: true, direct: true }).then(res => res ? JSON.parse(res) : {}).catch(() => ({}));
              window.browserGlobals.mutateObject(window.browserGlobals.localStorageStore, newLocalStorage);
              window.browserGlobals.updateIndexedDbStore(getCurProfileName());
            } catch (e) {}
            window.browserGlobals.allBrowsers.forEach((b) => b.tabs.forEach((t) => t.iframe.contentWindow.location.reload()));
            window.protectedGlobals.WriteFile("/systemfiles/runtime/apps/browser/defaultprofile.txt", btoa(p));
            try {
              await window.protectedGlobals.WriteFile(defaultPath, btoa(p));
            } catch (e) {}
            window.protectedGlobals.notification && window.protectedGlobals.notification("Switched profile to " + p + ". Reload tabs for it to take effect.");
          } catch (e) {
            window.protectedGlobals.notification && window.protectedGlobals.notification("Switched profile to " + p);
          }
          panel.remove();
        };

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.style.cssText = "background:#e04c4c;color:#fff;border:none;padding:6px 8px;border-radius:6px;cursor:pointer;";
        if (getCurProfileName() === p) {
          deleteBtn.disabled = true;
          deleteBtn.title = "Cannot delete current profile";
        }
        deleteBtn.onclick = async () => {
          const ok = await showConfirmDialog("Delete profile", `Delete profile '${p}'? This will remove profile files and cannot be undone.`);
          if (!ok) return;
          try {
            await window.protectedGlobals.DeleteFile("/systemfiles/runtime/apps/browser/" + p);
            // remove from profilepaths.txt
            try {
              let content = await window.protectedGlobals.ReadFile(listPath, { text: true, direct: true }).catch(() => "") || "";
              const lines2 = content.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
              const idx = lines2.indexOf(p);
              if (idx !== -1) lines2.splice(idx, 1);
              await window.protectedGlobals.WriteFile(listPath, btoa(lines2.join("\n")));
            } catch (e) {}
            window.protectedGlobals.notification && window.protectedGlobals.notification("Deleted profile " + p);
            panel.remove();
            showProfileDialogue();
          } catch (e) {
            window.protectedGlobals.notification && window.protectedGlobals.notification("Error deleting profile");
          }
        };

        right.appendChild(deleteBtn);
        right.appendChild(switchBtn);
        row.appendChild(right);
        list.appendChild(row);
      }
    }

    const btnRow = document.createElement("div");
    btnRow.style.cssText = "display:flex;justify-content:flex-end;gap:8px;margin-top:12px;";
    const btnClose = document.createElement("button");
    btnClose.textContent = "Close";
    btnClose.onclick = () => panel.remove();
    btnRow.appendChild(btnClose);
    panel.appendChild(btnRow);

    document.body.appendChild(panel);
  }
  let username = window.protectedGlobals.getCurrentUsernameForRequests();
  async function updateSiteSettings(iframe, content) {
    if (window.browserGlobals.profileReadyPromise) {
      await window.browserGlobals.profileReadyPromise;
    }

    window.browserGlobals.profileState.enableURLSync = !!content.enableURLSync;
    window.browserGlobals.profileState.lazyloading = !!content.lazyloading;
    if (content.lazyloading)
      window.browserGlobals.allBrowsers.forEach((b) =>
        b.tabs.forEach((t) => (t.iframe.loading = "lazy")),
      );
    else
      window.browserGlobals.allBrowsers.forEach((b) =>
        b.tabs.forEach((t) => (t.iframe.loading = "")),
      );

    const currentUrl = window.browserGlobals.mainWebsite(
      window.browserGlobals.unshuffleURL(iframe.src),
    );
    const profile =
      window.browserGlobals.profile || window.browserGlobals.defaultBrowserProfile();
    const list = Array.isArray(profile.siteSettings)
      ? profile.siteSettings
      : [];
    let updated = false;
    for (let i = 0; i < list.length; i++) {
      if (Array.isArray(list[i]) && list[i][0] === currentUrl) {
        list[i][1] = content.newSandbox;
        updated = true;
      }
    }
    if (!updated && content.addTheSite) {
      list.push([currentUrl, content.newSandbox]);
    }
    profile.siteSettings = list;
    profile.enableURLSync = !!content.enableURLSync;
    profile.lazyloading = !!content.lazyloading;
    window.browserGlobals.profile = profile;
    window.browserGlobals.profileState.siteSettings = profile.siteSettings;
    window.browserGlobals.profileState.enableURLSync = profile.enableURLSync;
    window.browserGlobals.profileState.lazyloading = profile.lazyloading;
    window.browserGlobals.profileState.siteZoom =
      profile.siteZoom && typeof profile.siteZoom === "object"
        ? profile.siteZoom
        : {};
    await window.browserGlobals.writeBrowserProfile(profile);

    iframe.sandbox = content.newSandbox;
  }
  function createPermInput(iframe, url) {
    url = window.browserGlobals.mainWebsite(url);

    let sandbox = `
    allow-forms
    allow-modals
    allow-orientation-lock
    allow-pointer-lock
    allow-presentation
    allow-same-origin
    allow-scripts
  `.trim();

    let fullscreen = true;
    let addTheSite = true;
    let siteSettings = window.browserGlobals.profileState.siteSettings;
    for (const site of siteSettings) {
      if (url === site[0]) {
        sandbox = site[1];
        addTheSite = false;
      }
    }
    iframe.sandbox = sandbox;
    return { sandbox, addTheSite };
  }
  function openPermissionsUI(url, iframe, anchorRect = null) {
    const perms = createPermInput(iframe, url) || {
      sandbox: "",
    };

    // --- Cleanup old UI
    document.getElementById("perm-ui")?.remove();

    // --- Floating panel
    const panel = document.createElement("div");
    panel.id = "perm-ui";
    panel.className = "panel";
    panel.classList.toggle("dark", window.browserGlobals.dark);
    panel.classList.toggle("light", !window.browserGlobals.dark);
    panel.style.cssText = `
    position:fixed;
    z-index:999999;
    width:320px;
    border-radius:10px;
    box-shadow:0 20px 60px rgba(0,0,0,.6);
    padding:14px;
    font-family:system-ui;
    font-size:13px;
    max-height:400px;
    overflow:auto;
  `;

    if (anchorRect) {
      panel.style.left = anchorRect.left + "px";
      panel.style.top = anchorRect.bottom + 6 + "px";
    } else {
      panel.style.left = "50%";
      panel.style.top = "50%";
      panel.style.transform = "translate(-50%,-50%)";
    }

    document.body.appendChild(panel);

    let closed = false;
    function closePermissionsPanel() {
      if (closed) return;
      closed = true;
      try {
        document.removeEventListener("pointerdown", onOutsidePointerDown, true);
      } catch (e) {}
      panel.remove();
    }

    function onOutsidePointerDown(event) {
      if (!panel.contains(event.target)) {
        closePermissionsPanel();
      }
    }

    setTimeout(() => {
      if (!closed) {
        document.addEventListener("pointerdown", onOutsidePointerDown, true);
      }
    }, 0);

    // --- Helpers
    const sandboxSet = new Set(
      perms.sandbox
        ?.split(" ")
        .map((v) => v.trim())
        .filter(Boolean),
    );

    function section(title) {
      const d = document.createElement("div");
      d.style.marginBottom = "10px";
      d.innerHTML = `<div style="font-weight:600;margin-bottom:6px">${title}</div>`;
      panel.appendChild(d);
      return d;
    }

    function checkbox(parent, label, checked, disabled = false) {
      const row = document.createElement("label");
      row.style.cssText =
        "display:flex;align-items:center;gap:6px;margin-bottom:4px;opacity:" +
        (disabled ? 0.5 : 1);
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = checked;
      cb.disabled = disabled;
      row.append(cb, document.createTextNode(label));
      parent.appendChild(row);
      return cb;
    }

    // ===============================
    // FULLSCREEN
    // ===============================
    let website = window.browserGlobals.mainWebsite(
      window.browserGlobals.unshuffleURL(iframe.src),
    );
    let secure = website.startsWith("https://")
      ? "Connection to this site is Secure"
      : "Connection to this site is Not Secure";
    if (website.startsWith("goldenbody://"))
      secure = "You are viewing a secure official goldenbody webpage";
    section(website);
    section(secure);
    if (!window.browserGlobals.profileState.enableURLSync)
      section(
        "Only user-initiated navigations get new permissions. To disable this, open sync perms below.",
      );
    // perms
    const syncpermsSec = section("Sync Perms");
    let syncperms = checkbox(
      syncpermsSec,
      "sync perms",
      window.browserGlobals.profileState.enableURLSync,
    );
    const info = document.createElement("div");
    info.style.cssText = `
    margin-top:6px;
    font-size:11px;
    color:#aaa;
  `;
    info.textContent =
      "Recommended if you want permissions to automatically update when you navigate to different sites. If disabled, permissions will only be set on the initial URL and won't change until you manually update them or open this panel again.";
    syncpermsSec.appendChild(info);
    let lazyloadingsect = section("Performance");
    let lazyloading = checkbox(
      lazyloadingsect,
      "Lazy Loading",
      window.browserGlobals.profileState.lazyloading,
    );

    // ===============================
    // SANDBOX
    // ===============================
    const sandboxSec = section("Site Settings");
    const SANDBOX_LIST = [
      "allow-forms",
      "allow-modals",
      "allow-orientation-lock",
      "allow-pointer-lock",
      "allow-presentation",
      "allow-scripts",
      "allow-same-origin", // LOCKED
    ];

    const sandboxCheckboxes = {};

    for (const perm of SANDBOX_LIST) {
      const locked = perm === "allow-same-origin";
      sandboxCheckboxes[perm] = checkbox(
        sandboxSec,
        perm + (locked ? " (locked)" : ""),
        sandboxSet.has(perm),
        locked,
      );
    }

    // Warning
    const warn = document.createElement("div");
    warn.style.cssText = `
    margin-top:6px;
    font-size:11px;
    color:#aaa;
  `;
    warn.textContent = "allow-same-origin cannot be changed.";
    sandboxSec.appendChild(warn);

    // ===============================
    // SITE DATA
    // ===============================
    const siteDataSec = section("Site Data");
    const siteDataTabs = document.createElement("div");
    siteDataTabs.style.display = "flex";
    siteDataTabs.style.gap = "6px";
    siteDataTabs.style.marginBottom = "8px";

    const siteDataTabCookies = document.createElement("button");
    siteDataTabCookies.textContent = "Cookies";
    const siteDataTabLocalStorage = document.createElement("button");
    siteDataTabLocalStorage.textContent = "LocalStorage";
    const siteDataTabIndexedDb = document.createElement("button");
    siteDataTabIndexedDb.textContent = "IndexedDB";
    const siteDataDesc = document.createElement("div");
    siteDataDesc.style.fontSize = "12px";
    siteDataDesc.style.opacity = "0.9";
    siteDataDesc.style.marginBottom = "8px";

    const siteDataClearBtn = document.createElement("button");
    siteDataClearBtn.style.background = "#8b1f1f";
    siteDataClearBtn.style.color = "#fff";

    function setSiteDataTabVisual(button, active) {
      button.style.border =
        "1px solid " + (active ? "#4c8bf5" : "rgba(127,127,127,.45)");
      button.style.borderRadius = "6px";
      button.style.padding = "5px 10px";
      button.style.cursor = "pointer";
      button.style.background = active ? "#4c8bf5" : "transparent";
      button.style.color = active ? "#fff" : "inherit";
    }

    let activeSiteDataTab = "cookies";
    function renderSiteDataTab() {
      const isCookies = activeSiteDataTab === "cookies";
      const isLocalStorage = activeSiteDataTab === "localstorage";
      const isIndexedDb = activeSiteDataTab === "indexeddb";
      setSiteDataTabVisual(siteDataTabCookies, isCookies);
      setSiteDataTabVisual(siteDataTabLocalStorage, isLocalStorage);
      setSiteDataTabVisual(siteDataTabIndexedDb, isIndexedDb);
      if (isCookies) {
        siteDataDesc.textContent = "Delete cookies only for this site.";
        siteDataClearBtn.textContent = "Clear site cookies";
      } else if (isIndexedDb) {
        siteDataDesc.textContent = "Delete IndexedDB data only for this site.";
        siteDataClearBtn.textContent = "Clear site IndexedDB";
      }
      else {
        siteDataDesc.textContent =
          "Delete localStorage data only for this site.";
        siteDataClearBtn.textContent = "Clear site localStorage";
      }
    }

    siteDataTabCookies.onclick = () => {
      activeSiteDataTab = "cookies";
      renderSiteDataTab();
    };
    siteDataTabLocalStorage.onclick = () => {
      activeSiteDataTab = "localstorage";
      renderSiteDataTab();
    };
    siteDataTabIndexedDb.onclick = () => {
      activeSiteDataTab = "indexeddb";
      renderSiteDataTab();
    };
    siteDataClearBtn.onclick = async () => {
      if (activeSiteDataTab === "cookies") {
        const shouldClearCookies = await showConfirmDialog(
          "Clear site cookies",
          `This will remove cookies for ${website}. Continue?`,
        );
        if (!shouldClearCookies) return;
        await window.browserGlobals.clearCookiesForSite(website);
        window.protectedGlobals.notification("cookies cleared for this site");
        return;
      }

      if (activeSiteDataTab === "localstorage") {
        const shouldClearLocalStorage = await showConfirmDialog(
          "Clear site localStorage",
          `This will remove localStorage for ${website}. Continue?`,
        );
        if (!shouldClearLocalStorage) return;
        await window.browserGlobals.clearLocalStorageForSite(website);
        window.protectedGlobals.notification(
          "localstorage cleared for this site",
        );
        return;
      }
      
      if (activeSiteDataTab === "indexeddb") {
        const shouldClearIndexedDb = await showConfirmDialog(
          "Clear site IndexedDB",
          `This will remove IndexedDB for ${website}. Continue?`,
        );
        if (!shouldClearIndexedDb) return;
        await window.browserGlobals.clearIndexedDbForSite(website);
        window.protectedGlobals.notification(
          "indexeddb cleared for this site",
        );
        return;
      }
    };

    siteDataTabs.append(
      siteDataTabCookies,
      siteDataTabLocalStorage,
      siteDataTabIndexedDb,
    );
    siteDataSec.append(siteDataTabs, siteDataDesc, siteDataClearBtn);
    renderSiteDataTab();

    // ===============================
    // ACTIONS
    // ===============================
    const actions = document.createElement("div");
    actions.style.cssText = `
    display:flex;
    justify-content:flex-end;
    gap:8px;
    margin-top:12px;
  `;

    const cancel = document.createElement("button");
    cancel.textContent = "Cancel";
    cancel.onclick = () => closePermissionsPanel();

    const apply = document.createElement("button");
    apply.textContent = "Apply";
    apply.style.background = "#4c8bf5";
    apply.style.color = "#fff";

    apply.onclick = () => {
      // ===== LOGIC HOOK (YOU IMPLEMENT) =====
      window.protectedGlobals.notification(
        "reload this page to apply your updated settings!",
      );

      const newSandbox = Object.entries(sandboxCheckboxes)
        .filter(([_, cb]) => cb.checked)
        .map(([k]) => k)
        .join(" ");

      updateSiteSettings(iframe, {
        newSandbox: newSandbox,
        addTheSite: perms.addTheSite,
        enableURLSync: syncperms.checked,
        lazyloading: lazyloading.checked,
      });

      closePermissionsPanel();
    };

    actions.append(cancel, apply);
    panel.appendChild(actions);
  }

  var checkInterval = null;
  var activatedTab = 0;
  let isMaximized = false;
  let _isMinimized = false;
  if (posX < 0) {
    posX = 0;
  }
  if (posY < 0) {
    posY = 0;
  }
  window.protectedGlobals.atTop = "browser";
  const chromeWindow = (function createChromeLikeUI() {
    // --- Create root container ---
    var root = document.createElement("div");
    getRoot = function () { return root; };
    root.__moveTabListenerAdded = false;
    root.className = "app-root app-window-root";
    root.dataset.appId = "browser";
    Object.assign(root.style, {
      position: "fixed",
      top: posY + "px",
      left: posX + "px",
      width: "1000px",
      height: "640px",
      boxShadow: "0 12px 40px rgba(0,0,0,0.35)",
      borderRadius: "10px",
      overflow: "hidden",
    });
    window.protectedGlobals.bringToFront(root);
    root._goldenbodyId = assignedId;
    window.browserGlobals.goldenbodyOrderId++;
    root._goldenbodyOrderId = window.browserGlobals.goldenbodyOrderId;
    root.tabIndex = "0";
    // Respect per-app ignore flag; compute effective browser dark mode
    // If a window has `data-theme-manual` set to 'true', flowaway.window.protectedGlobals.applyStyles
    // will avoid changing its theme classes. Initialize based on profile.
    try {
      const pm =
        window.browserGlobals.profile && window.browserGlobals.profile.themeMode
          ? window.browserGlobals.profile.themeMode
          : "auto";
      if (pm === "manual") {
        root.dataset.themeManual = "true";
        // ensure this root reflects the pinned theme
        try {
          root.classList.toggle("dark", !!window.browserGlobals.dark);
          root.classList.toggle("light", !window.browserGlobals.dark);
        } catch (e) {}
      } else {
        root.dataset.themeManual = "false";
      }
    } catch (e) {
      root.dataset.themeManual = root.dataset.themeManual || "false";
    }
    root.addEventListener("styleapplied", () => {
      // If user preference is 'auto' then mirror global `window.protectedGlobals.data.dark`, otherwise use stored profile value
      try {
        const pm =
          window.browserGlobals.profile &&
          window.browserGlobals.profile.themeMode
            ? window.browserGlobals.profile.themeMode
            : "auto";
        if (pm === "auto") {
          window.browserGlobals.dark = !!(
            window.protectedGlobals.data && window.protectedGlobals.data.dark
          );
        } else {
          window.browserGlobals.dark = !!window.browserGlobals.profile.dark;
        }
      } catch (e) {
        window.browserGlobals.dark = !!(
          window.protectedGlobals.data && window.protectedGlobals.data.dark
        );
      }

      for (const tab of tabs) {
        tab.iframe.contentWindow.postMessage({
          __goldenbodyChangeTheme__: true,
          dark: window.browserGlobals.dark,
        });
      }
    });
    root.__gbShortcutDedupe = { sig: "", ts: 0 };
    function runBrowserShortcut(key, eventLike = null) {
      const normalized = String(key || "").toLowerCase();
      if (normalized !== "t" && normalized !== "n") return false;

      const now = Date.now();
      const sig = `${normalized}:1`;
      if (
        root.__gbShortcutDedupe &&
        root.__gbShortcutDedupe.sig === sig &&
        now - root.__gbShortcutDedupe.ts < 180
      ) {
        if (eventLike && (eventLike.preventDefault)) {
          eventLike.preventDefault();
        }
        return true;
      }
      root.__gbShortcutDedupe = { sig, ts: now };

      if (eventLike && (eventLike.preventDefault)) {
        eventLike.preventDefault();
      }
      if (normalized === "t") {
        addTab("goldenbody://newtab/", "New Tab");
        return true;
      }
      console.log("Running browser shortcut for new window");
      browser();
      return true;
    }

    function cycleBrowserTabs(reverse = false) {
      if (!Array.isArray(tabs) || tabs.length < 2) return false;
      const currentIndex = tabs.findIndex((tab) => tab.id === activeTabId);
      if (currentIndex < 0) return false;
      const delta = reverse ? -1 : 1;
      const nextIndex = (currentIndex + delta + tabs.length) % tabs.length;
      const nextTab = tabs[nextIndex];
      if (!nextTab) return false;
      activateTab(nextTab.id);
      return true;
    }

    function closeActiveBrowserTab() {
      if (!Array.isArray(tabs) || !tabs.length) return false;
      const active = tabs.find((tab) => tab.id === activeTabId) || activatedTab;
      if (!active || !active.id) return false;
      closeTab(active.id);
      return true;
    }

    function runBrowserCtrlShortcut(e) {
      if (!e) return false;
      if (e.__gbBrowserCtrlHandled) return true;

      const keyRaw = String(e.key || "");
      const key = keyRaw.toLowerCase();
      const isCtrlLike = !!(e.ctrlKey || e.metaKey);
      if (!isCtrlLike) return false;

      if (e.altKey && (key === "arrowright" || key === "arrowleft")) {
        e.preventDefault();
        if ((e.stopPropagation)) e.stopPropagation();
        e.__gbBrowserCtrlHandled = true;
        cycleBrowserTabs(key === "arrowleft");
        return true;
      }

      if (e.altKey) return false;

      if (key === "w") {
        e.preventDefault();
        if ((e.stopPropagation)) e.stopPropagation();
        e.__gbBrowserCtrlHandled = true;
        closeActiveBrowserTab();
        return true;
      }

      if (key === "t" || key === "n") {
        const handled = runBrowserShortcut(key, e);
        if (handled) {
          if ((e.stopPropagation)) e.stopPropagation();
          e.__gbBrowserCtrlHandled = true;
        }
        return handled;
      }

      return false;
    }

    root.addEventListener("keydown", (e) => {
      runBrowserCtrlShortcut(e);
    });

    function getActiveBrowserTab() {
      return tabs.find((tab) => tab.id === activeTabId) || activatedTab || null;
    }

    function dispatchShortcutToActiveBrowserTab(eventInit) {
      const tab = getActiveBrowserTab();
      const target = tab && tab.iframe && tab.iframe.contentWindow;
      if (!target) return false;
      try {
        target.dispatchEvent(
          new KeyboardEvent("keydown", {
            bubbles: true,
            cancelable: true,
            composed: true,
            ...eventInit,
          }),
        );
        return true;
      } catch (e) {
        return false;
      }
    }

    function showBrowserActionsMenu(anchorEl) {
      if (!anchorEl) return;

      document.getElementById("browser-actions-menu")?.remove();

      const menu = document.createElement("div");
      menu.id = "browser-actions-menu";
      menu.style.position = "fixed";
      menu.style.zIndex = "100";
      menu.style.minWidth = "220px";
      menu.style.padding = "6px 0";
      menu.style.borderRadius = "8px";
      menu.style.boxShadow = "0 10px 30px rgba(0,0,0,0.35)";
      menu.style.background = window.browserGlobals.dark ? "#1f1f1f" : "#ffffff";
      menu.style.color = window.browserGlobals.dark ? "#f5f5f5" : "#222";
      menu.style.border = window.browserGlobals.dark
        ? "1px solid #444"
        : "1px solid #d0d0d0";
      const closeMenu = () => {
        menu.remove();
        window.removeEventListener("click", closeMenu);
        window.removeEventListener("keydown", onEsc);
      };

      const addItem = (label, handler, disabled = false) => {
        const item = document.createElement("div");
        item.textContent = label;
        item.style.padding = "7px 12px";
        item.style.cursor = disabled ? "not-allowed" : "pointer";
        item.style.userSelect = "none";
        item.style.opacity = disabled ? "0.45" : "1";
        item.addEventListener("mouseenter", () => {
          if (!disabled)
            item.style.background = window.browserGlobals.dark ? "#333" : "#eef4ff";
        });
        item.addEventListener("mouseleave", () => {
          item.style.background = "transparent";
        });
        item.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (disabled) return;
          closeMenu();
          handler();
        });
        menu.appendChild(item);
      };

      const activeTab = getActiveBrowserTab();
      const hasActiveTab = !!(activeTab && activeTab.iframe);
      addItem("New tab", () => runBrowserShortcut("t"));
      addItem("New window", () => runBrowserShortcut("n"));
      addItem(
        "Close tab",
        () => {
          if (activeTab) closeTab(activeTab.id);
        },
        !hasActiveTab,
      );
      addItem(
        "Reload tab",
        () => {
          if ((reloadBtn.onclick)) reloadBtn.onclick();
          else if (
            activeTab &&
            activeTab.iframe &&
            activeTab.iframe.contentWindow
          ) {
            let tmp = window.browserGlobals.unshuffleURL(activeTab.iframe.src);
            if (looksLikeLocalFilePath(tmp)) {
              openUrlInActiveTab(tmp);
            } else {
              activeTab.iframe.contentWindow.location.reload();
            }
          }
        },
        !hasActiveTab,
      );
      addItem(
        "Zoom in",
        () => {
          dispatchShortcutToActiveBrowserTab({ key: "+", ctrlKey: true });
        },
        !hasActiveTab,
      );
      addItem(
        "Zoom out",
        () => {
          dispatchShortcutToActiveBrowserTab({ key: "-", ctrlKey: true });
        },
        !hasActiveTab,
      );
      addItem(
        "Open DevTools",
        () => {
          dispatchShortcutToActiveBrowserTab({
            key: "i",
            ctrlKey: true,
            shiftKey: true,
          });
        },
        !hasActiveTab,
      );
      addItem(
        "change RAF speed",
        () => {
          showSetSpeedDialogue();
        }
      );
      addItem(
        "load userscript",
        () => {
          showUserscriptDialogue();
        }
      );
      addItem(
        "Switch profile",
        () => {
          showProfileDialogue();
        }
      );
      addItem("Delete browsing data", () => {
        clearBrowsingData();
      });

      menu.appendChild(document.createElement("hr"));

      const rect = anchorEl.getBoundingClientRect();
      menu.style.left = `${Math.min(window.innerWidth - 240, rect.right - 220)}px`;
      menu.style.top = `${Math.min(window.innerHeight - 260, rect.bottom + 6)}px`;
      document.body.appendChild(menu);

      const onEsc = (e) => {
        if (e.key === "Escape") closeMenu();
      };
      requestAnimationFrame(() => {
        window.addEventListener("click", closeMenu, { once: true });
        window.addEventListener("keydown", onEsc, { once: true });
      });
    }

    root.addEventListener("click", (e) => {
      // App-specific click handler can be implemented here
      window.protectedGlobals.bringToFront(root);
    });
    document.addEventListener("browser" + root._goldenbodyId, "click", (e) => {
      // Scoped listener for browser app cleanup
    });
    root.classList.add("browser");
    // --- Top area ---
    const top = document.createElement("div");
    top.className = "sim-chrome-top";
    top.style.justifyContent = "space-between";
    root.appendChild(top);

    top.addEventListener("click", function () {
      window.protectedGlobals.bringToFront(root);
    });
    var topBar = false;
    if (!topBar) {
      topBar = document.createElement("div");
      topBar.className = "appTopBar";
      topBar.style.display = "flex";
      topBar.style.justifyContent = "flex-end";
      topBar.style.alignItems = "center";
      topBar.style.padding = "2px";
      topBar.style.cursor = "move";
      topBar.style.flexShrink = "0";
      topBar.style.position = "static";
      topBar.style.top = "";
      topBar.style.right = "";
      topBar.style.marginLeft = "auto";
    }

    var btnMin = document.createElement("button");
    btnMin.title = "Minimize";
    btnMin.className = "btnMinColor";
    topBar.appendChild(btnMin);

    var btnMax = document.createElement("button");
    btnMax.className = "btnMaxColor";
    btnMax.title = "Maximize/Restore";
    topBar.appendChild(btnMax);

    var btnClose = document.createElement("button");
    btnClose.title = "Close";
    btnClose.style.color = "white";
    btnClose.style.backgroundColor = "red";
    topBar.appendChild(btnClose);

    [topBar, btnMin, btnMax, btnClose].forEach((el) => {
      el.style.margin = "0 2px";
      el.style.border = "none";
      el.style.padding = "4px 6px";
      el.style.fontSize = "14px";
      el.style.cursor = "pointer";
    });
    const applyWindowControlIcon =
      window.protectedGlobals.applyWindowControlIcon || function () {};
    const setWindowMaximizeIcon =
      window.protectedGlobals.setWindowMaximizeIcon || function () {};
    applyWindowControlIcon(btnMin, "minimize");
    setWindowMaximizeIcon(btnMax, false);
    applyWindowControlIcon(btnClose, "close");

    function getBounds() {
      return {
        left: root.style.left,
        top: root.style.top,
        width: root.style.width,
        height: root.style.height,
        position: root.style.position || "fixed",
      };
    }
    var savedBounds = getBounds();
    let renderInterval = null;

    function applyBounds(b) {
      root.style.position = "absolute";
      root.style.left = b.left;
      root.style.top = b.top;
      root.style.width = b.width;
      root.style.height = b.height;
    }

    function maximizeWindow() {
      savedBounds = getBounds();
      root.style.position = "absolute";
      root.style.left = "0";
      root.style.top = "0";
      root.style.width = "100%";
      root.style.height = !window.protectedGlobals.data.autohidetaskbar
        ? `calc(100% - 60px)`
        : "100%";
      root.style.borderRadius = "0px";
      isMaximized = true;
      _isMinimized = false;
      setWindowMaximizeIcon(btnMax, true);
    }

    function restoreWindow(useOriginalBounds = true) {
      if (useOriginalBounds && savedBounds) {
        applyBounds(savedBounds);
      }
      root.style.borderRadius = "10px";
      isMaximized = false;
      _isMinimized = false;
      setWindowMaximizeIcon(btnMax, false);
    }

    // MINIMIZE
    btnMin.addEventListener("click", function () {
      if (!isMaximized) savedBounds = getBounds();
      root.style.display = "none";
      _isMinimized = true;
    });

    // MAXIMIZE / RESTORE
    btnMax.addEventListener("click", function () {
      if (!isMaximized) {
        maximizeWindow();
      } else {
        restoreWindow(true);
      }
    });
    if (preMaximized) {
      maximizeWindow();
    }
    // CLOSE
    btnClose.addEventListener("click", closeWindow);
    function closeWindow() {
      try {
        clearInterval(renderInterval);
      } catch (e) {}
      try {
        clearInterval(checkerinterval);
      } catch(e) {}

      root.remove();

      // Remove from window.browserGlobals.allBrowsers
      const index = window.browserGlobals.allBrowsers.indexOf(chromeWindow);
      if (index !== -1) {
        window.browserGlobals.allBrowsers.splice(index, 1);
      }
      window.removeEventListener("message", messageHandler);
      window.removeEventListener("pointerup", onpointerupAnywhere);
      // Clean up all event listeners added by this app
      window.protectedGlobals.removeAllEventListenersForApp(
        root.dataset.appId + root._goldenbodyId,
      );
      window.browserGlobals.releaseBrowserGoldenbodyId(root);
      root = null;
      _browserCalled = false;
    }

    const tabsRow = document.createElement("div");
    tabsRow.className = "sim-chrome-tabs";
    tabsRow.style.flex = "0 1 auto";
    tabsRow.style.minWidth = "0px";
    tabsRow.style.overflowX = "auto";
    tabsRow.style.whiteSpace = "nowrap";

    // new tab button
    const newTabBtn = document.createElement("button");
    newTabBtn.className = "sim-open-btn";
    newTabBtn.innerText = "+";
    newTabBtn.title = "New tab";
    Object.assign(newTabBtn.style, {
      width: "28px",
      padding: "6px",
      fontSize: "16px",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: "0",
    });

    // address row
    const addressRow = document.createElement("div");
    addressRow.className = "sim-address-row";
    root.appendChild(addressRow);

    const urlInput = document.createElement("input");
    urlInput.className = "sim-url-input";
    urlInput.type = "text";
    urlInput.placeholder =
      "Enter URL (e.g. https://example.com, goldenbody://newtab/, goldenbody://app-store/)";
    urlInput.autocapitalize = "off";
    urlInput.autocomplete = "off";
    urlInput.spellcheck = false;
    addressRow.appendChild(urlInput);
    const applyAddressIconButtonStyle = (button) => {
      Object.assign(button.style, {
        minWidth: "34px",
        padding: "0 12px",
        fontSize: "16px",
      });
    };

    const addressIconSvg = {
      settings:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 8.92 4.6H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.16.5.65.85 1.19.85H21a2 2 0 1 1 0 4h-.41c-.54 0-1.03.35-1.19.85z"></path></svg>',
      reload:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <!-- circular arc (stops earlier to leave a gap) --> <path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/> <!-- arrow --> <polyline points="20 4 20 9 15 9"/> </svg>',
      forward:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
      back: '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
      clear:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"></path></svg>',
      download:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
      theme:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><line x1="12" y1="1" x2="12" y2="4"></line><line x1="12" y1="20" x2="12" y2="23"></line><line x1="1" y1="12" x2="4" y2="12"></line><line x1="20" y1="12" x2="23" y2="12"></line><line x1="4.2" y1="4.2" x2="6.3" y2="6.3"></line><line x1="17.7" y1="17.7" x2="19.8" y2="19.8"></line><line x1="4.2" y1="19.8" x2="6.3" y2="17.7"></line><line x1="17.7" y1="6.3" x2="19.8" y2="4.2"></line></svg>',
      stop_loading:
        '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" style="display:block;margin:auto" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>',
    };

    const setAddressButtonIcon = (button, iconName) => {
      button.innerHTML = addressIconSvg[iconName] || "";
    };

    const openBtn = document.createElement("button");
    openBtn.className = "sim-open-btn";
    openBtn.title = "open url";
    setAddressButtonIcon(openBtn, "forward");
    addressRow.appendChild(openBtn);

    var sitesettingsbtn = document.createElement("button");
    sitesettingsbtn.title = "Site Settings";
    setAddressButtonIcon(sitesettingsbtn, "settings");
    sitesettingsbtn.className = "sim-open-btn";
    applyAddressIconButtonStyle(sitesettingsbtn);

    addressRow.prepend(sitesettingsbtn);

    var reloadBtn = document.createElement("button");
    reloadBtn.title = "Reload";
    reloadBtn.className = "sim-open-btn";
    applyAddressIconButtonStyle(reloadBtn);
    setAddressButtonIcon(reloadBtn, "reload");
    reloadBtn.dataset.mode = "reload";
    addressRow.prepend(reloadBtn);

    var forwardBtn = document.createElement("button");
    forwardBtn.title = "Forward";
    setAddressButtonIcon(forwardBtn, "forward");
    forwardBtn.className = "sim-open-btn";
    applyAddressIconButtonStyle(forwardBtn);
    addressRow.prepend(forwardBtn);

    var backBtn = document.createElement("button");
    backBtn.title = "Back";
    setAddressButtonIcon(backBtn, "back");
    backBtn.className = "sim-open-btn";
    applyAddressIconButtonStyle(backBtn);
    addressRow.prepend(backBtn);

    var clear = document.createElement("button");
    setAddressButtonIcon(clear, "clear");
    clear.title = "delete browsing data";
    clear.className = "sim-open-btn";
    applyAddressIconButtonStyle(clear);

    function openDownloadUI(anchorPoint = null) {
      document.getElementById("download-ui")?.remove();

      const panel = document.createElement("div");
      panel.id = "download-ui";
      panel.className = "panel";
      panel.classList.toggle("dark", window.browserGlobals.dark);
      panel.classList.toggle("light", !window.browserGlobals.dark);
      panel.style.cssText =
        "position:fixed;z-index:999999;width:420px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

      let closed = false;

      function cleanup() {
        if (closed) return;
        closed = true;
        try {
          panel.remove();
        } catch (e) {}
        try {
          document.removeEventListener("pointermove", onPointerMove);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUp);
        } catch (e) {}
        try {
          document.removeEventListener(
            "pointerdown",
            onOutsidePointerDown,
            true,
          );
        } catch (e) {}
      }

      function onOutsidePointerDown(event) {
        if (!panel.contains(event.target)) {
          cleanup();
        }
      }

      const title = document.createElement("div");
      title.style.cssText = "font-weight:600;margin-bottom:8px;cursor:grab";
      title.textContent = "Download URL";
      panel.appendChild(title);

      const label = document.createElement("div");
      label.style.cssText = "font-size:12px;color:#888;margin-bottom:6px";
      label.textContent = "Enter URL to download";
      panel.appendChild(label);

      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = "https://example.com/file.png";
      input.style.cssText =
        "width:100%;padding:8px;margin-bottom:8px;border-radius:6px;border:1px solid #ccc";
      try {
        input.value =
          activatedTab && activatedTab.iframe && activatedTab.iframe.src
            ? window.browserGlobals.unshuffleURL(activatedTab.iframe.src)
            : "";
      } catch (e) {}
      panel.appendChild(input);

      const computeName = (u) => {
        try {
          const parsed = new URL(u);
          let n = parsed.pathname.split("/").pop() || "";
          if (!n || n === "/")
            n =
              parsed.searchParams.get("filename") ||
              parsed.searchParams.get("file") ||
              "";
          if (!n) n = "download";
          return n.split("?")[0];
        } catch (e) {
          return "download";
        }
      };

      const info = document.createElement("div");
      info.style.cssText = "font-size:12px;color:#666;margin-bottom:8px";
      info.textContent = "Filename: " + computeName(input.value || "");
      panel.appendChild(info);
      input.oninput = () => {
        info.textContent = "Filename: " + computeName(input.value || "");
      };

      const btnRow = document.createElement("div");
      btnRow.style.cssText =
        "display:flex;justify-content:flex-end;gap:8px;margin-top:6px";
      const btnCancel = document.createElement("button");
      btnCancel.textContent = "Cancel";
      btnCancel.onclick = () => cleanup();
      const btnDownload = document.createElement("button");
      btnDownload.textContent = "Download";
      btnDownload.style.background = "#4c8bf5";
      btnDownload.style.color = "#fff";
      btnDownload.onclick = async () => {
        const url = (input.value || "").trim();
        if (!url) return window.protectedGlobals.notification("Enter a URL");
        const filename = computeName(url);
        try {
          if ((window.protectedGlobals.downloadPost)) {
            await window.protectedGlobals.downloadPost({ href: url, filename });
            window.protectedGlobals.notification("Download request sent");
          } else {
            window.protectedGlobals.notification("downloadPost not available");
          }
        } catch (e) {
          console.error("downloadPost error", e);
          window.protectedGlobals.notification("Download failed to start");
        }
        cleanup();
      };
      btnRow.appendChild(btnCancel);
      btnRow.appendChild(btnDownload);
      panel.appendChild(btnRow);

      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let origLeft = 0;
      let origTop = 0;
      function onPointerMove(e) {
        if (!isDragging) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        panel.style.left = origLeft + dx + "px";
        panel.style.top = origTop + dy + "px";
        panel.style.transform = "";
      }
      function onPointerUp() {
        if (!isDragging) return;
        isDragging = false;
        title.style.cursor = "grab";
        try {
          document.removeEventListener("pointermove", onPointerMove);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUp);
        } catch (e) {}
      }
      title.addEventListener("pointerdown", (ev) => {
        ev.preventDefault();
        isDragging = true;
        startX = ev.clientX;
        startY = ev.clientY;
        const r = panel.getBoundingClientRect();
        origLeft = r.left;
        origTop = r.top;
        title.style.cursor = "grabbing";
        document.addEventListener("pointermove", onPointerMove);
        document.addEventListener("pointerup", onPointerUp);
      });

      document.body.appendChild(panel);

      setTimeout(() => {
        if (!closed) {
          document.addEventListener("pointerdown", onOutsidePointerDown, true);
        }
      }, 0);

      if (
        anchorPoint &&
        typeof anchorPoint.x === "number" &&
        typeof anchorPoint.y === "number"
      ) {
        const rect = panel.getBoundingClientRect();
        const viewportW =
          window.innerWidth || document.documentElement.clientWidth || 0;
        const viewportH =
          window.innerHeight || document.documentElement.clientHeight || 0;
        let left = anchorPoint.x - rect.width;
        let top = anchorPoint.y;
        left = Math.max(0, Math.min(left, Math.max(0, viewportW - rect.width)));
        top = Math.max(0, Math.min(top, Math.max(0, viewportH - rect.height)));
        panel.style.left = left + "px";
        panel.style.top = top + "px";
        panel.style.transform = "";
      } else {
        panel.style.left = "50%";
        panel.style.top = "50%";
        panel.style.transform = "translate(-50%,-50%)";
      }
    }

    var downloadBtn = document.createElement("button");
    downloadBtn.title = "Download URL";
    downloadBtn.className = "sim-open-btn";
    applyAddressIconButtonStyle(downloadBtn);
    setAddressButtonIcon(downloadBtn, "download");
    downloadBtn.onclick = function (e) {
      const buttonRect = downloadBtn.getBoundingClientRect();
      const x = buttonRect.right || 0;
      const y = buttonRect.top || 0;
      openDownloadUI({ x, y });
    };

    function openThemeUI(anchorPoint = null) {
      document.getElementById("theme-ui")?.remove();

      let closed = false;
      function cleanup() {
        if (closed) return;
        closed = true;
        try {
          panel.remove();
        } catch (e) {}
        try {
          document.removeEventListener(
            "pointerdown",
            onOutsidePointerDown,
            true,
          );
        } catch (e) {}
        try {
          document.removeEventListener("pointermove", onPointerMoveTheme);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUpTheme);
        } catch (e) {}
      }

      const panel = document.createElement("div");
      panel.id = "theme-ui";
      panel.className = "panel";
      panel.classList.toggle("dark", window.browserGlobals.dark);
      panel.classList.toggle("light", !window.browserGlobals.dark);
      panel.style.cssText =
        "position:fixed;z-index:999999;width:320px;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6);padding:14px;font-family:system-ui;font-size:13px;";

      function onOutsidePointerDown(event) {
        if (!panel.contains(event.target)) {
          cleanup();
        }
      }

      const title = document.createElement("div");
      title.style.cssText = "font-weight:600;margin-bottom:8px;cursor:grab";
      title.textContent = "Change Theme";
      panel.appendChild(title);

      const desc = document.createElement("div");
      desc.style.cssText = "font-size:12px;color:#888;margin-bottom:8px";
      desc.textContent =
        "Choose theme for this browser app (light/dark/default).";
      panel.appendChild(desc);

      const form = document.createElement("div");
      form.style.cssText = "display:flex;flex-direction:column;gap:8px;";

      function radioOption(value, label, checked) {
        const row = document.createElement("label");
        row.style.cssText = "display:flex;align-items:center;gap:8px;";
        const r = document.createElement("input");
        r.type = "radio";
        r.name = "gb-theme-mode";
        r.value = value;
        r.checked = !!checked;
        row.appendChild(r);
        row.appendChild(document.createTextNode(label));
        return row;
      }

      const currentMode =
        window.browserGlobals.profile && window.browserGlobals.profile.themeMode
          ? window.browserGlobals.profile.themeMode
          : "auto";
      const manualDark = !!(
        window.browserGlobals.profile && window.browserGlobals.profile.dark
      );

      form.appendChild(
        radioOption(
          "auto",
          "Default (system preference)",
          currentMode === "auto",
        ),
      );
      form.appendChild(
        radioOption("light", "Light", currentMode === "manual" && !manualDark),
      );
      form.appendChild(
        radioOption("dark", "Dark", currentMode === "manual" && manualDark),
      );

      // No per-window ignore checkbox — manual theme selection will pin
      // theme for all browser windows by setting `data-theme-manual` on roots.

      panel.appendChild(form);

      const actions = document.createElement("div");
      actions.style.cssText =
        "display:flex;justify-content:flex-end;gap:8px;margin-top:12px;";
      const btnCancel = document.createElement("button");
      btnCancel.textContent = "Cancel";
      btnCancel.onclick = () => cleanup();
      const btnApply = document.createElement("button");
      btnApply.textContent = "Apply";
      btnApply.style.background = "#4c8bf5";
      btnApply.style.color = "#fff";
      btnApply.onclick = async () => {
        const chosen =
          Array.from(
            panel.querySelectorAll('input[name="gb-theme-mode"]'),
          ).find((i) => i.checked)?.value || "auto";
        try {
          window.browserGlobals.profile = window.browserGlobals.profile || {};
          if (chosen === "auto") {
            window.browserGlobals.profile.themeMode = "auto";
          } else {
            window.browserGlobals.profile.themeMode = "manual";
            window.browserGlobals.profile.dark = chosen === "dark";
          }
          await window.browserGlobals.writeBrowserProfile(
            window.browserGlobals.profile,
            { force: true },
          );
        } catch (e) {}
        // update effective dark
        try {
          if (
            window.browserGlobals.profile &&
            window.browserGlobals.profile.themeMode === "auto"
          ) {
            window.browserGlobals.dark = !!(
              window.protectedGlobals.data && window.protectedGlobals.data.dark
            );
          } else {
            window.browserGlobals.dark = !!(
              window.browserGlobals.profile && window.browserGlobals.profile.dark
            );
          }
        } catch (e) {
          window.browserGlobals.dark = !!(
            window.protectedGlobals.data && window.protectedGlobals.data.dark
          );
        }

        // If manual, pin theme on all browser roots so `window.protectedGlobals.applyStyles` won't
        // override them. If auto, remove the pin so `window.protectedGlobals.applyStyles` manages them.
        try {
          const allRoots = document.querySelectorAll(
            '.app-window-root[data-app-id="browser"]',
          );
          for (const rr of allRoots) {
            if (
              window.browserGlobals.profile &&
              window.browserGlobals.profile.themeMode === "manual"
            ) {
              rr.dataset.themeManual = "true";
              rr.classList.toggle("dark", window.browserGlobals.dark);
              rr.classList.toggle("light", !window.browserGlobals.dark);
            } else {
              try {
                delete rr.dataset.themeManual;
              } catch (e) {
                rr.dataset.themeManual = "false";
              }
              // Ensure the root reflects the effective (global) theme immediately
              try {
                rr.classList.toggle("dark", !!window.browserGlobals.dark);
                rr.classList.toggle("light", !window.browserGlobals.dark);
              } catch (e) {}
            }
          }
        } catch (e) {}

        // Dispatch styleapplied to notify apps
        try {
          allRoots = [];
          window.browserGlobals.allBrowsers.forEach((b) => {
            try {
              const r = b.rootElement;
              if (r) allRoots.push(r);
            } catch (e) {}
          });
          for (const r of allRoots) {
            try {
              r.dispatchEvent(new CustomEvent("styleapplied", {}));
            } catch (e) {}
          }
        } catch (e) {}

        cleanup();
      };
      actions.append(btnCancel, btnApply);
      panel.appendChild(actions);

      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let origLeft = 0;
      let origTop = 0;
      function onPointerMoveTheme(e) {
        if (!isDragging) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        panel.style.left = origLeft + dx + "px";
        panel.style.top = origTop + dy + "px";
        panel.style.transform = "";
      }
      function onPointerUpTheme() {
        if (!isDragging) return;
        isDragging = false;
        title.style.cursor = "grab";
        try {
          document.removeEventListener("pointermove", onPointerMoveTheme);
        } catch (e) {}
        try {
          document.removeEventListener("pointerup", onPointerUpTheme);
        } catch (e) {}
      }
      title.addEventListener("pointerdown", (ev) => {
        ev.preventDefault();
        isDragging = true;
        startX = ev.clientX;
        startY = ev.clientY;
        const r = panel.getBoundingClientRect();
        origLeft = r.left;
        origTop = r.top;
        title.style.cursor = "grabbing";
        document.addEventListener("pointermove", onPointerMoveTheme);
        document.addEventListener("pointerup", onPointerUpTheme);
      });

      document.body.appendChild(panel);

      setTimeout(() => {
        if (!closed) {
          document.addEventListener("pointerdown", onOutsidePointerDown, true);
        }
      }, 0);

      if (
        anchorPoint &&
        typeof anchorPoint.x === "number" &&
        typeof anchorPoint.y === "number"
      ) {
        const rect = panel.getBoundingClientRect();
        const viewportW =
          window.innerWidth || document.documentElement.clientWidth || 0;
        const viewportH =
          window.innerHeight || document.documentElement.clientHeight || 0;
        let left = anchorPoint.x - rect.width;
        let top = anchorPoint.y;
        left = Math.max(0, Math.min(left, Math.max(0, viewportW - rect.width)));
        top = Math.max(0, Math.min(top, Math.max(0, viewportH - rect.height)));
        panel.style.left = left + "px";
        panel.style.top = top + "px";
        panel.style.transform = "";
      } else {
        panel.style.left = "50%";
        panel.style.top = "50%";
        panel.style.transform = "translate(-50%,-50%)";
      }
    }

    async function clearBrowsingData() {
      const confirmClear = await showConfirmDialog(
        "Clear site data",
        "This will reset site settings and clear your browsing data. Continue?",
      );
      if (!confirmClear) return;
      // dead code but dont delete so the thing works
      id = window.browserGlobals.id;
      await window.browserGlobals.writeBrowserUserId(id);
      window.browserGlobals.profile = {
        siteSettings: [],
        enableURLSync: true,
        lazyloading: true,
        siteZoom: {},
      };
      await window.browserGlobals.writeBrowserProfile(
        window.browserGlobals.profile,
        { force: true },
      );
      window.browserGlobals.profileState.siteSettings = [];
      window.browserGlobals.profileState.enableURLSync = true;
      window.browserGlobals.profileState.lazyloading = true;
      window.browserGlobals.profileState.siteZoom = {};
      await window.browserGlobals.clearAllCookies();
      await window.browserGlobals.clearAllLocalStorage();
      window.protectedGlobals.notification(
        "site data cleared! please close all browser windows!",
      );
    }
    clear.onclick = clearBrowsingData;

    addressRow.appendChild(downloadBtn);
    // Theme button
    var themeBtn = document.createElement("button");
    themeBtn.className = "sim-open-btn";
    themeBtn.title = "Theme";
    setAddressButtonIcon(themeBtn, "theme");
    applyAddressIconButtonStyle(themeBtn);
    themeBtn.onclick = function (e) {
      const r = themeBtn.getBoundingClientRect();
      openThemeUI({ x: r.right, y: r.top + r.height });
    };
    addressRow.appendChild(themeBtn);
    const browserActionsBtn = document.createElement("button");
    browserActionsBtn.className = "sim-open-btn";
    browserActionsBtn.title = "More browser actions";
    browserActionsBtn.textContent = "⋯";
    applyAddressIconButtonStyle(browserActionsBtn);
    browserActionsBtn.style.fontSize = "18px";
    browserActionsBtn.style.fontWeight = "700";
    browserActionsBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      showBrowserActionsMenu(browserActionsBtn);
    });
    addressRow.appendChild(browserActionsBtn);

    const resizeDiv = document.createElement("div");
    resizeDiv.style.backgroundColor = "gray"; // visible
    resizeDiv.style.position = "absolute";
    resizeDiv.style.width = "5%";
    resizeDiv.style.height = "3%";
    resizeDiv.style.left = "85%";
    resizeDiv.style.top = "10%";
    resizeDiv.style.zIndex = "9999";
    resizeDiv.style.display = "none";

    addressRow.prepend(resizeDiv);

    root.addEventListener("pointerdown", function () {
      resizeDiv.style.display = "none";
    });

    // ⟳ ⋮
    // iframes
    var iframes = [];

    const leftGroup = document.createElement("div");
    leftGroup.style.display = "flex";
    leftGroup.style.alignItems = "center";
    leftGroup.className = "leftgroup";
    leftGroup.style.gap = "0px";
    leftGroup.style.flex = "1";
    leftGroup.style.minWidth = "0";
    leftGroup.appendChild(tabsRow);

    top.appendChild(leftGroup);
    top.appendChild(topBar);
    document.body.appendChild(root);

    let tabs = [];
    let activeTabId = null;
    let tabCounter = 0;

    // with this:
    tabsRow.style.display = "flex";
    tabsRow.style.flex = "1 1 0"; // <-- grow and be the thing that shrinks
    tabsRow.style.minWidth = "0"; // <-- required for flex children to actually shrink container
    tabsRow.style.flexWrap = "nowrap";
    tabsRow.style.overflowX = "auto";
    tabsRow.style.overflowY = "hidden";
    leftGroup.style.flex = "1 1 auto";
    leftGroup.style.minWidth = "0";
    window.browserGlobals.tabisDragging = false;

    let dragid = "";
    let dragindex = 0;
    let nativeTabDrag = false;
    let dragoverReordered = false;
    let crossWindowTransferHandled = false;
    const resetTabDragState = () => {
      window.browserGlobals.tabisDragging = false;
      dragMoved = false;
      window.browserGlobals.draggedtab = null;
      dragid = "";
      dragindex = 0;
      nativeTabDrag = false;
      dragoverReordered = false;
      crossWindowTransferHandled = false;
    };
    const onpointerupAnywhere = (ev, notontab) => {
      const eventTarget =
        ev?.target ||
        (typeof ev?.clientX === "number" && typeof ev?.clientY === "number"
          ? document.elementFromPoint(ev.clientX, ev.clientY)
          : null);
      if (!eventTarget && !notontab) return;
      if (!window.browserGlobals.tabisDragging) return;
      if (!window.browserGlobals.dragstartwindow || !window.browserGlobals.draggedtab) {
        resetTabDragState();
        return;
      }

      // Check if pointerup happened on a tab
      let targetTab;
      try {
        targetTab = eventTarget?.closest(".sim-tab");
      } catch (e) {}
      try {
        let tabbarHit = false;
        let targetBrowser = null;

        for (const b of window.browserGlobals.allBrowsers) {
          if (
            b.rootElement.querySelector(".sim-chrome-top").contains(eventTarget)
          ) {
            tabbarHit = true;
            targetBrowser = b;
            break;
          }
        }
        if (tabbarHit) {
          // Determine the element under the cursor
          const dropTarget =
            document.elementFromPoint(ev.clientX, ev.clientY) || eventTarget;

          // Detect which window the cursor is over
          let targetBrowser = null;

          for (const b of window.browserGlobals.allBrowsers) {
            if (b.rootElement.contains(dropTarget)) {
              targetBrowser = b;
              break;
            }
          }
          // If dropped in the same window: do nothing
          if (targetBrowser === window.browserGlobals.dragstartwindow) {
            // reset drag state
            resetTabDragState();
            return;
          }

          // If dropped in another window
          if (targetBrowser) {
            if (crossWindowTransferHandled) {
              resetTabDragState();
              return;
            }
            crossWindowTransferHandled = true;
            targetBrowser.addTab(
              window.browserGlobals.draggedtab.url,
              "",
              window.browserGlobals.draggedtab.resizeP,
              { forceRender: true },
            );
            window.browserGlobals.dragstartwindow.closeTab(
              window.browserGlobals.draggedtab.id,
              { forceRender: true },
            );
            resetTabDragState();
            return;
          }

          resetTabDragState();
          return;
        }
      } catch (e) {}
      if (!targetTab || targetTab.id !== dragid) {
        // pointerup happened somewhere else
        if (crossWindowTransferHandled) {
          resetTabDragState();
          return;
        }
        crossWindowTransferHandled = true;
        browser(
          window.browserGlobals.dragstartwindow.tabs[dragindex].url,
          window.browserGlobals.draggedtab.resizeP,
          ev.clientX - 100,
          ev.clientY - 20,
        ); // your custom function
        // console.log(root);
        window.browserGlobals.dragstartwindow.closeTab(window.browserGlobals.draggedtab.id);
      }

      resetTabDragState();
    };
    function messageHandler(event) {
      const data = event.data;
      if (data?.type === "iframe-pointerup") {
        // console.log("pointerup from iframe:");
        // console.log("Coordinates:", data.x, data.y);
        // console.log("Button pressed:", data.button);

        // You can reconstruct a pseudo-event:
        const e = {
          clientX: data.x,
          clientY: data.y,
          pageX: data.pageX,
          pageY: data.pageY,
          button: data.button,
          buttons: data.buttons,
          altKey: data.altKey,
          ctrlKey: data.ctrlKey,
          shiftKey: data.shiftKey,
          metaKey: data.metaKey,
        };
        onpointerupAnywhere(e, true);
        // Use pseudoEvent however you want
        let pointerup = new MouseEvent("pointerup", e);
        document.dispatchEvent(pointerup);
        window.dispatchEvent(pointerup);
        let pointerdown = new MouseEvent("pointerdown", e);
        document.dispatchEvent(pointerdown);
        window.dispatchEvent(pointerdown);
        let CLICK = new MouseEvent("click", e);
        document.dispatchEvent(CLICK);
        window.dispatchEvent(CLICK);
      }
    }
    window.addEventListener("message", messageHandler);
    window.addEventListener("pointerup", onpointerupAnywhere);
    renderInterval = setInterval(() => {
      if (!window.browserGlobals.allBrowsers.some((b) => b.rootElement === root)) {
        clearInterval(renderInterval);
        console.warn("interval cleared, root missing!");
      }
      renderTabs();
    }, 10000);
    function renderTabs(forceRender = false) {
      if (!forceRender && (window.browserGlobals.tabisDragging || nativeTabDrag)) return;
      var ids = 0;
      while (tabsRow.firstChild) tabsRow.removeChild(tabsRow.firstChild);
      leftGroup.appendChild(newTabBtn);

      // tabs
      tabs.forEach((t) => {
        const el = document.createElement("div");
        // inside renderTabs(), after creating el
        el.style.flex = "0 0 auto";
        el.id = "id-" + ids;
        ids++;
        el.draggable = true;
        el.name = "tabs";
        el.style.minWidth = "13.5%"; // or 150–185px if you want a bigger minimum
        el.style.maxWidth = "13.5%";
        el.style.overflow = "hidden";
        el.style.display = "flex";
        el.style.whiteSpace = "nowrap";
        el.tabIndex = "0";

        el.setAttribute("draggable", "true");
        let temptab = 0;
        function countChild(parent, targetElement) {
          const children = parent.children;
          let count = 0;

          for (let i = 0; i < children.length; i++) {
            if (children[i] === targetElement) {
              break; // Stop counting when you reach the target element
            }
            count++;
          }

          return count;
        }
        function moveTabInArray(tabs, fromIndex, toIndex) {
          if (fromIndex === -1 || toIndex === -1 || fromIndex === toIndex)
            return tabs;

          const [moved] = tabs.splice(fromIndex, 1);

          // After removing an earlier element, the target index shifts down by 1
          if (fromIndex < toIndex) toIndex--;

          tabs.splice(toIndex, 0, moved);
          return tabs;
        }
        el.addEventListener("pointerup", function () {
          root.focus();
        });
        el.addEventListener("pointerdown", (ev) => {
          if (ev.target.classList.contains("close")) return;
          if (activeTabId !== t.id) activateTab(t.id);
        });
        el.addEventListener("pointerup", function () {
          window.protectedGlobals.bringToFront(root);
        });
        el.addEventListener("dragstart", (ev) => {
          window.browserGlobals.dragstartwindow = chromeWindow;
          window.browserGlobals.tabisDragging = true;
          nativeTabDrag = true;
          dragoverReordered = false;
          dragMoved = false;
          dragindex = countChild(tabsRow, el);
          console.log("dragindex:", dragindex);
          window.browserGlobals.draggedtab = tabs[dragindex];
          dragid = el.id;
          try {
            if (ev.dataTransfer) {
              ev.dataTransfer.effectAllowed = "move";
              ev.dataTransfer.setData("text/plain", dragid);
            }
          } catch (e) {}
        });

        el.addEventListener("dragover", (e) => {
          if (
            !(
              window.browserGlobals.tabisDragging &&
              window.browserGlobals.dragstartwindow === chromeWindow
            )
          )
            return;
          e.preventDefault();
          dragMoved = true;
          dragoverReordered = true;

          const draggedelement = root.querySelector(`#${dragid}`);
          if (!draggedelement || draggedelement === el) return;

          const isDraggingRight =
            draggedelement.compareDocumentPosition(el) &
            Node.DOCUMENT_POSITION_FOLLOWING;

          let newIndex = countChild(tabsRow, el);
          if (isDraggingRight) newIndex++;

          tabs = moveTabInArray(tabs, dragindex, newIndex);
          tabsRow.insertBefore(
            draggedelement,
            isDraggingRight ? el.nextSibling : el,
          );
          dragindex = countChild(tabsRow, draggedelement);
        });

        el.addEventListener("dragend", (e) => {
          if (!window.browserGlobals.tabisDragging) return;
          onpointerupAnywhere({
            clientX: e.clientX,
            clientY: e.clientY,
            target: document.elementFromPoint(e.clientX, e.clientY) || e.target,
          });
          resetTabDragState();
          renderTabs();
        });

        el.addEventListener("pointermove", () => {
          if (window.browserGlobals.tabisDragging) dragMoved = true;
        });

        el.addEventListener("pointerup", (e) => {
          if (nativeTabDrag) {
            return;
          }
          if (
            window.browserGlobals.tabisDragging &&
            dragMoved &&
            window.browserGlobals.dragstartwindow === chromeWindow
          ) {
            const draggedelement = root.querySelector(`#${dragid}`);
            if (!draggedelement || draggedelement === el) return;

            // Determine if dragging right
            const isDraggingRight =
              draggedelement.compareDocumentPosition(el) &
              Node.DOCUMENT_POSITION_FOLLOWING;

            // Compute new index BEFORE inserting
            let newIndex = countChild(tabsRow, el);
            if (isDraggingRight) newIndex++; // insert after target

            // Update array first
            tabs = moveTabInArray(tabs, dragindex, newIndex);

            // Then update DOM
            tabsRow.insertBefore(
              draggedelement,
              isDraggingRight ? el.nextSibling : el,
            );
          }
          if (
            window.browserGlobals.tabisDragging &&
            dragMoved &&
            window.browserGlobals.dragstartwindow !== chromeWindow
          ) {
            onpointerupAnywhere(e);
          }

          resetTabDragState();
        });

        const title = el.querySelector(".sim-tab-title");
        if (title) title.style.textOverflow = "ellipsis";
        el.className = "sim-tab" + (t.id === activeTabId ? " active" : "");
        el.title = t.title || "Untitled";
        el.innerHTML = `<span style='display: inline-block;overflow: hidden;white-space: nowrap; text-overflow: ellipsis;' class='sim-tab-title'>${t.title || "Untitled"}</span>
                    <span class='close' title='Close tab'>&times;</span>`;
        // close handler
        el.querySelector(".close").addEventListener("click", (ev) => {
          ev.stopPropagation();
          closeTab(t.id);
        });
        tabsRow.appendChild(el);
        tabsRow.appendChild(newTabBtn);
      });
      // reorder tabs
    }
    window.addEventListener(
      "browser" + root._goldenbodyId,
      "message",
      function (e) {
        if (e.data.type === "FROM_IFRAME") {
          addTab(e.data.message, "New Tab");
        } else if (
          e.data.__goldenbodynewWindow__ &&
          root ===
            window.browserGlobals.allBrowsers[e.data.allbrowserindex].rootElement
        ) {
          addTab(e.data.url, "New Tab");
        }
      },
    );
    //render tab end----------------------------------------------------------

    function addTab(url, title, resizeP = preloadsize, options = {}) {
      const id = "tab-" + ++tabCounter;
      const iframe = document.createElement("iframe");
      if (window.browserGlobals.profileState.lazyloading) iframe.loading = "lazy";
      iframe.onload = () => {
        try {
          // Try to access its document
          const doc = iframe.contentDocument || iframe.contentWindow.document;
          // let script = document.createElement('script');
          // script.textContent = `
          // const nativePostMessage = window.postMessage;
          // window.postMessage = function(msg, target) {
          //   nativePostMessage.call(window, msg, target);
          // };
          // `;
          // doc.appendChild(sc)
          // If site unreachable, doc will often be null
          if (!doc || doc.body.innerHTML.trim() === "") {
            console.log("Site unreachable or failed to load.");
          } else {
            console.log("Loaded successfully.");
          }
        } catch (e) {
          // Cross-origin frame loaded, but we can’t read its contents.
          console.log(
            "Loaded, but cannot access due to cross-origin restrictions.",
          );
        }
      };
      iframe.addEventListener("load", function () {
        if (!iframe.contentWindow.eruda) {
          const script = iframe.contentDocument.createElement("script");
          script.src = window.browserGlobals.erudaCDN;
          script.onload = () => {
            iframe.contentWindow.eruda.init();
            iframe.contentWindow.eruda.get("entryBtn").hide();
          };
          iframe.contentDocument.head.appendChild(script);
        }
        iframe.contentWindow.postMessage(
          {
            message: "GOLDENBODY_id",
            website: window.protectedGlobals.goldenbodywebsite,
            value: window.browserGlobals.id,
            dark: window.browserGlobals.dark,
          },
          "*",
        );
        function getSiteZoomKeyForTab(tab) {
          try {
            const current = String(
              tab.iframe.contentWindow.location &&
                tab.iframe.contentWindow.location.href
                ? tab.iframe.contentWindow.location.href
                : tab.url || "",
            );
            const unshuffled = window.browserGlobals.unshuffleURL(current);
            try {
              const u = new URL(unshuffled);
              return (u.protocol + "//" + u.host).toLowerCase();
            } catch (e) {
              return window.browserGlobals.mainWebsite(unshuffled).toLowerCase();
            }
          } catch (e) {
            return "";
          }
        }

        function applyZoomToTab(tab) {
          let resizescript = document.createElement("script");
          resizescript.textContent = `document.body.style.zoom = ${tab.resizeP} + '%' || '100%'; // shrink page inside iframe`;
          tab.iframe.contentDocument.head.appendChild(resizescript);
        }

        function persistSiteZoomForTab(tab) {
          const key = getSiteZoomKeyForTab(tab);
          if (!key) return;
          const profile =
            window.browserGlobals.profile ||
            window.browserGlobals.defaultBrowserProfile();
          if (!profile.siteZoom || typeof profile.siteZoom !== "object") {
            profile.siteZoom = {};
          }
          profile.siteZoom[key] = tab.resizeP;
          window.browserGlobals.profile = profile;
          window.browserGlobals.profileState.siteZoom = profile.siteZoom;
          try {
            if (window.browserGlobals.__siteZoomPersistTimer) {
              clearTimeout(window.browserGlobals.__siteZoomPersistTimer);
            }
            window.browserGlobals.__siteZoomPersistTimer = setTimeout(() => {
              window.browserGlobals
                .writeBrowserProfile(profile)
                .catch(() => {});
            }, 220);
          } catch (e) {}
        }

        function loadSiteZoomForTab(tab) {
          const key = getSiteZoomKeyForTab(tab);
          if (!key) return;
          const profile =
            window.browserGlobals.profile ||
            window.browserGlobals.defaultBrowserProfile();
          const siteZoom =
            profile.siteZoom && typeof profile.siteZoom === "object"
              ? profile.siteZoom
              : {};
          const z = Number(siteZoom[key]);
          if (Number.isFinite(z)) {
            tab.resizeP = Math.max(25, Math.min(500, Math.round(z)));
          } else {
            tab.resizeP = 100;
          }
        }

        loadSiteZoomForTab(tab);
        let resizelastTimeout = 0;
        function handleresize(e, tab) {
          try {
            if (e.ctrlKey && (e.key === "=" || e.key === "+")) {
              e.preventDefault();
              tab.resizeP += 5;
              if (tab.resizeP > 500) tab.resizeP = 500;
              resizeDiv.style.display = "block";
              applyZoomToTab(tab);
              persistSiteZoomForTab(tab);
              clearTimeout(resizelastTimeout);
              resizelastTimeout = setTimeout(() => {
                resizeDiv.style.display = "none";
              }, 3000);
            } else if (e.ctrlKey && e.key === "-") {
              e.preventDefault();
              tab.resizeP -= 5;
              if (tab.resizeP < 25) tab.resizeP = 25;
              resizeDiv.style.display = "block";
              applyZoomToTab(tab);
              persistSiteZoomForTab(tab);
              clearTimeout(resizelastTimeout);
              resizelastTimeout = setTimeout(() => {
                resizeDiv.style.display = "none";
              }, 3000);
            } else {
              resizeDiv.style.display = "none";
            }
          } catch (e) {}
        }
        function handleresizel1(e) {
          handleresize(e, tab);
        }

        try {
          if (tab.__onResizeKeydown && tab.__resizeKeyTarget) {
            tab.__resizeKeyTarget.removeEventListener(
              "keydown",
              tab.__onResizeKeydown,
            );
          }
        } catch (e) {}
        tab.__onResizeKeydown = handleresizel1;
        tab.__resizeKeyTarget = tab.iframe.contentWindow;
        tab.__resizeKeyTarget.addEventListener(
          "keydown",
          tab.__onResizeKeydown,
        );
        if (!tab.iframe.style.display === "none")
          urlInput.value = window.browserGlobals.unshuffleURL(
            iframe.contentWindow.location.href,
          );
        applyZoomToTab(tab);
        // let sfc = tab.iframe.contentDocument.createElement("script");
        // sfc.src = window.protectedGlobals.goldenbodywebsite + "sfc__o.js";
        // tab.iframe.contentDocument.head.prepend(sfc);
      });
      iframe.addEventListener("load", function onLoad() {
        const doc = iframe.contentDocument;
        const win = iframe.contentWindow;

        // Skip if unloaded or invalid
        if (!doc || !win) return;

        // Remove old handler if exists
        win.removeEventListener("keydown", win.erudaKeyHandler);

        // Define new handler
        win.erudaKeyHandler = function (e) {
          if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "i") {
            if (!win.eruda) {
              iframe.contentWindow._goldenbodyIns = true;

              const script = doc.createElement("script");
              script.src = window.browserGlobals.erudaCDN;
              script.onload = () => {
                win.eruda.init();
                win.eruda.get("entryBtn").hide();
                win.eruda.show();
              };
              doc.head.appendChild(script);
            } else {
              try {
                // toggle show/hide
                if (!win._goldenbodyIns) {
                  win.eruda.show();

                  win._goldenbodyIns = true;
                } else {
                  win.eruda.hide();

                  win._goldenbodyIns = false;
                }
              } catch (e) {
                console.error(e);
              }
            }
          }
        };

        // Attach handler
        win.addEventListener("keydown", win.erudaKeyHandler);
      });
      const titleInterval = setInterval(() => {
        try {
          if (!tab.iframe || !tab.iframe.contentDocument) {
            clearInterval(titleInterval);
            console.warn("Interval cleared: tab.iframe is gone");
            return;
          }
          tab.url = window.browserGlobals.unshuffleURL(
            tab.iframe.contentWindow.location.href,
          );
          if (tab.iframe.contentDocument.readyState === "complete" && !tab.donotm) {
            const docTitle =
              tab.iframe.contentDocument.title ||
              tab.iframe.contentDocument.querySelector("title")?.childNodes[0]
                ?.nodeValue ||
              window.browserGlobals.unshuffleURL(
                tab.iframe.contentWindow.location.href,
              ) ||
              "Untitled";
            tab.title = docTitle;
            if (tab.iframe.style.display === "block") chromeWindow.title = tab.title;
          } else {
            tab.title = "Loading...";
          }
        } catch (e) {
          console.warn("Interval cleared due to error:", e);
        }
        if (previousTabTitle !== tab.title) renderTabs();
        previousTabTitle = tab.title;
      }, 1000 * window.browserGlobals.nhjd);

      createPermInput(iframe, url);
      if (window.browserGlobals.profileReadyPromise) {
        window.browserGlobals.profileReadyPromise
          .then(() => {
            try {
              createPermInput(
                iframe,
                window.browserGlobals.unshuffleURL(
                  iframe.contentWindow.location.href || url,
                ),
              );
            } catch (e) {
              try {
                createPermInput(iframe, url);
              } catch (ee) {}
            }
          })
          .catch(() => {});
      }
      iframe.tabIndex = "0";
      iframe.className = "sim-iframe";
      console.log(iframe);
      let tab = { iframe, firstNav: true, id };
      activatedTab = tab;
      eval(window.browserGlobals.iframePatch);
      stopIframePatchWatcher = exposedToTabs.stopIframePatchWatcher;
      
      if (window.browserGlobals.proxyurl != "") {
        iframe.src = a(url, window.browserGlobals.proxyurl);
        // oof we dont need this anymore
        // if(!window.browserGlobals.profileState.enableURLSync) {
        // setTimeout(() => {
        //   // to fix a contextmenu not showing bug, thats what i can do because after checking the devtools, idk what happened.
        //   iframe.contentWindow.location.reload();
        // }, 250);
        // }
      } else {
        iframe.src = url;
      }
      iframe.style.display = "none";
      root.appendChild(iframe);
      let loadedurl = url;
      let donotm = false;
      let RAFSpeed = 1;
      tab = {
        RAFSpeed,
        setRAFSpeed: (val) => {
          tab.RAFSpeed = val;
          const recurseFunc = tab.iframe.__gbRecurseFrames;
          if (recurseFunc) {
            recurseFunc(tab.iframe.contentDocument, undefined, tab.iframe, undefined, { speed: val });
          }
        },
        id,
        firstNav: true,
        url,
        title,
        iframe,
        resizeP,
        loadedurl,
        donotm,
        history: {
          stack: [url],
          index: 0,
          current: url,
          currentCanonical: null,
          suppressNextRecord: false,
        },
      };
      tab.history.currentCanonical = canonicalHistoryUrl(url);
      tab.__stopIframePatchWatcher = stopIframePatchWatcher;

      if (preloadsize !== 100) {
        preloadsize = 100;
      }
      function handleReload(e) {
        if (
          e.ctrlKey &&
          e.key === "r" &&
          (document.activeElement === root ||
            document.activeElement === tab.iframe) &&
          tab.iframe.style.display === "block"
        ) {
          e.preventDefault();
          let tmp = window.browserGlobals.unshuffleURL(
            tab.iframe.contentWindow.location.href,
          );
          if (looksLikeLocalFilePath(tmp)) {
            openUrlInActiveTab(tmp);
          } else {
            tab.iframe.contentWindow.location.reload();
          }
        }
      }
      root.addEventListener("keydown", handleReload);
      tab.__onRootKeydown = handleReload;

      let previousTabTitle = tab.title;

      tab.title = "Loading...";

      tabs.push(tab);
      activateTab(id, !!options.forceRender);
      renderTabs(!!options.forceRender);
      const onDocumentKeyup = function (e) {
        try {
          if (!root.contains(document.activeElement)) return;
        } catch (e) {
          return;
        }
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "i") {
          e.preventDefault();
          e.stopPropagation();

          const win = tab.iframe.contentWindow;
          const doc = tab.iframe.contentDocument;
          if (!win || tab.iframe.style.display === "none") return;
          if (!win.eruda) {
            tab.iframe.contentWindow._goldenbodyIns = true;

            const script = doc.createElement("script");
            script.src = window.browserGlobals.erudaCDN;
            script.onload = () => {
              win.eruda.init();
              win.eruda.get("entryBtn").hide();
              win.eruda.show();
            };
            doc.head.appendChild(script);
          }
          win.eruda[win._goldenbodyIns ? "hide" : "show"]();
          win._goldenbodyIns = !win._goldenbodyIns;
        }
      };
      document.addEventListener(
        "browser" + root._goldenbodyId,
        "keyup",
        onDocumentKeyup,
      );
      tab.__onDocumentKeyup = onDocumentKeyup;

      return id;
    }
    window.addEventListener(
      "browser" + root._goldenbodyId,
      "keydown",
      function (e) {
        try {
          if (
            document.activeElement !== root &&
            !root.contains(document.activeElement)
          )
            return;
        } catch (e) {
          return;
        }
        if (e.ctrlKey && e.altKey) {
          e.preventDefault();
          if (e.key === "ArrowRight") {
            for (let i = 0; i < tabs.length; i++) {
              if (tabs[i].id === activatedTab.id) {
                activateTab(tabs[i + 1].id);
                break;
              }
            }
          } else if (e.key === "ArrowLeft") {
            let lastindex = 0;
            for (let i = 0; i < tabs.length; i++) {
              let currentIndex = i;
              if (tabs[i].id === activatedTab.id) {
                activateTab(tabs[lastindex].id);
                break;
              }
              lastindex = currentIndex;
            }
          }
        }
      },
    );

    function canonicalHistoryUrl(url) {
      if (!url) return "";
      const raw = String(url);
      const hashIndex = raw.indexOf("#");
      const queryIndex = raw.indexOf("?");
      let splitIndex = raw.length;

      if (queryIndex !== -1 && queryIndex < splitIndex) {
        splitIndex = queryIndex;
      }
      if (hashIndex !== -1 && hashIndex < splitIndex) {
        splitIndex = hashIndex;
      }

      let head = raw.slice(0, splitIndex);
      const tail = raw.slice(splitIndex);

      if (head.length > 1) {
        head = head.replace(/\/+$/, "");
      }

      return head + tail;
    }

    function historyRecord(tab, url) {
      if (!tab || !tab.history || !url) return;
      const canonical = canonicalHistoryUrl(url);
      if (tab.history.suppressNextRecord) {
        tab.history.suppressNextRecord = false;
        if (
          Array.isArray(tab.history.stack) &&
          tab.history.index >= 0 &&
          tab.history.index < tab.history.stack.length
        ) {
          const currentStackUrl = tab.history.stack[tab.history.index];
          tab.history.current = currentStackUrl;
          tab.history.currentCanonical = canonicalHistoryUrl(currentStackUrl);
          return;
        }
        tab.history.current = url;
        tab.history.currentCanonical = canonical;
        return;
      }
      if (
        Array.isArray(tab.history.stack) &&
        tab.history.index >= 0 &&
        tab.history.index < tab.history.stack.length
      ) {
        const currentStackCanonical = canonicalHistoryUrl(
          tab.history.stack[tab.history.index],
        );
        if (currentStackCanonical === canonical) {
          tab.history.current = url;
          tab.history.currentCanonical = canonical;
          return;
        }
      }
      if (tab.history.currentCanonical === canonical) return;

      if (tab.history.index < tab.history.stack.length - 1) {
        tab.history.stack = tab.history.stack.slice(0, tab.history.index + 1);
      }
      tab.history.stack.push(url);
      tab.history.index = tab.history.stack.length - 1;
      tab.history.current = url;
      tab.history.currentCanonical = canonical;
    }

    async function historyNavigate(tab, direction) {
      if (!tab || !tab.history) return;
      const nextIndex = tab.history.index + direction;
      if (nextIndex < 0 || nextIndex >= tab.history.stack.length) return;

      const targetUrl = tab.history.stack[nextIndex];
      tab.history.index = nextIndex;
      tab.history.current = targetUrl;
      tab.history.currentCanonical = canonicalHistoryUrl(targetUrl);
      tab.history.suppressNextRecord = true;

      tab.url = targetUrl;
      tab.loadedurl = targetUrl;
      tab.title = "Loading...";

      try {
        createPermInput(tab.iframe, targetUrl);
      } catch (e) {}
      if (String(targetUrl).startsWith("file://")) {
        try {
          cleanupLocalFileNav(tab);
          const localPath = normalizeLocalFilePath(targetUrl);
          let blobUrl = window.browserGlobals.__localFilePathToBlobMap.get(localPath);
          if (!blobUrl) {
            const localNav = await resolveLocalFileNavigation(localPath);
            blobUrl = localNav.iframeSrc;
            tab.__localFileNav = localNav;
          } else {
            tab.__localFileNav = {
              iframeSrc: blobUrl,
              historyUrl: `file://${localPath}`,
              displayUrl: `file://${localPath}`,
              blobUrl,
              isLocal: true,
            };
          }
          tab.iframe.src = blobUrl;
          urlInput.value = `file://${localPath}`;
          return;
        } catch (e) {
          tab.history.suppressNextRecord = false;
          window.protectedGlobals.notification(
            "Unable to open file from history",
          );
          return;
        }
      }
      try {
        tab.iframe.contentWindow.location.href = a(
          targetUrl,
          window.browserGlobals.proxyurl,
        );
      } catch (e) {
        tab.history.suppressNextRecord = false;
      }
    }

    function activateTab(id, forceRender = false) {
      try {
        clearInterval(checkInterval);
      } catch (a) {}
      const tab = tabs.find((t) => t.id === id);
      if (!tab) return;
      tab.iframe.focus();
      activatedTab = tab;
      // Hide all iframes, show only active
      tabs.forEach((t) => (t.iframe.style.display = "none"));
      tab.iframe.style.display = "block";
      backBtn.onclick = function () {
        historyNavigate(tab, -1);
      };
      forwardBtn.onclick = function () {
        historyNavigate(tab, 1);
      };
      reloadBtn.onclick = function () {
        if (reloadBtn.dataset.mode === "stop") {
          tab.iframe.contentWindow.stop();
        } else {
          let tmp = window.browserGlobals.unshuffleURL(
            tab.iframe.contentWindow.location.href,
          );
          if (looksLikeLocalFilePath(tmp)) {
            openUrlInActiveTab(tmp);
          } else {
            tab.iframe.contentWindow.location.reload();
          }
        }
      };
      sitesettingsbtn.onclick = () => {
        openPermissionsUI(
          window.browserGlobals.unshuffleURL(tab.iframe.contentWindow.location.href),
          tab.iframe,
          sitesettingsbtn.getBoundingClientRect(),
        );
      };
      activeTabId = id;
      urlInput.value = window.browserGlobals.unshuffleURL(
        tab.iframe.contentWindow.location.href,
      );
      let previousUrl = canonicalHistoryUrl(
        window.browserGlobals.unshuffleURL(tab.iframe.contentWindow.location.href),
      );
      let previousTabTitle = tab.title;
      let previousUrlMain = window.browserGlobals.unshuffleURL(
        tab.iframe.contentWindow.location.href,
      );

      // Inject custom styles
      checkInterval = setInterval(() => {
        try {
          if (
            window.browserGlobals.allBrowsers.length == 0 ||
            !tab.iframe.contentDocument
          ) {
            clearInterval(checkInterval);
          }
        } catch (e) {
          clearInterval(checkInterval);
        }
        try {
          title = tab.iframe.contentDocument.title || "Untitled";
          const currentUrl = window.browserGlobals.unshuffleURL(
            tab.iframe.contentWindow.location.href,
          );
          const currentCanonical = canonicalHistoryUrl(currentUrl);
          if (currentCanonical !== previousUrl) {
            tab.firstNav = false;
            historyRecord(tab, currentUrl);
            previousUrl = currentCanonical;
            urlInput.value = currentUrl;
          }
          if (
            currentUrl !== previousUrlMain &&
            (currentUrl.startsWith("http") ||
              currentUrl.startsWith("goldenbody") ||
              currentUrl.startsWith("goldenbody://"))
          ) {
            if (
              window.browserGlobals.mainWebsite(currentUrl) !==
                window.browserGlobals.mainWebsite(previousUrlMain) &&
              currentUrl !== "about:blank" &&
              previousUrl !== ""
            )
              if (window.browserGlobals.profileState.enableURLSync) {
                openUrlInActiveTab(currentUrl);
              }
            if (window.browserGlobals.id == "") {
              window.browserGlobals.fetchId();
              setTimeout(() => {
                tab.iframe.contentWindow.location.reload();
              }, 250);
            }
            previousUrlMain = currentUrl;
          }
          resizeDiv.innerText = tab.resizeP + "%";
          if (tab.iframe.contentDocument.readyState !== "complete") {
            setAddressButtonIcon(reloadBtn, "stop_loading");
            reloadBtn.dataset.mode = "stop";

            tab.title = "Loading...";
          } else {
            setAddressButtonIcon(reloadBtn, "reload");
            reloadBtn.dataset.mode = "reload";
            // try {
            //   if (tab.iframe.contentDocument.readyState === "complete") {
            //     const docTitle =
            //       tab.iframe.contentDocument.title || tab.iframe.contentDocument.querySelector('title').childNodes[0].nodeValue  || tab.iframe.contentWindow.location.href || "Untitled";
            //     tab.title = docTitle;
            //   }
            // } catch (e) {}
          }
          if (previousTabTitle !== tab.title) renderTabs();
          previousTabTitle = tab.title;
        } catch (e) {
          console.error(e);
        }
      }, 250 * window.browserGlobals.nhjd);
      renderTabs(forceRender);
    }

    function closeTab(id, options = {}) {
      const forceRender = !!options.forceRender;
      const idx = tabs.findIndex((t) => t.id === id);
      if (idx === -1) return;

      const removingActive = tabs[idx].id === activeTabId;
      try {
        tabs[idx].__stopIframePatchWatcher?.();
      } catch (e) {}
      try {
        if (tabs[idx].__onRootKeydown) {
          root.removeEventListener("keydown", tabs[idx].__onRootKeydown);
        }
      } catch (e) {}
      try {
        if (tabs[idx].__onResizeKeydown && tabs[idx].__resizeKeyTarget) {
          tabs[idx].__resizeKeyTarget.removeEventListener(
            "keydown",
            tabs[idx].__onResizeKeydown,
          );
        }
      } catch (e) {}
      try {
        if (tabs[idx].__onDocumentKeyup) {
          document.removeEventListener("keyup", tabs[idx].__onDocumentKeyup);
        }
      } catch (e) {}
      cleanupLocalFileNav(tabs[idx]);
      tabs[idx].iframe.src = "about:blank";
      tabs[idx].iframe.remove();
      tabs.splice(idx, 1);

      if (removingActive) {
        if (tabs.length) activateTab(tabs[Math.max(0, idx - 1)].id, forceRender);
        else closeWindow(); //addTab('goldenbody://newtab/', 'New Tab');
      } else {
        renderTabs(forceRender);
      }
    }
    if (!preloadlink) addTab("goldenbody://newtab/", "New Tab");

    // --- Open button behavior ---
    function normalizeUrl(input) {
      if (input[input.length - 1] != "/") input += "/";

      if (
        input[0] +
          input[1] +
          input[2] +
          input[3] +
          input[4] +
          input[5] +
          input[6] +
          input[7] !=
          "https://" &&
        input[0] +
          input[1] +
          input[2] +
          input[3] +
          input[4] +
          input[5] +
          input[6] !=
          "http://" &&
        !input.startsWith("goldenbody://")
      )
        return "https://" + input;
      else return input;
    }
    function isUrl(string) {
      try {
        new URL(string);
        return true;
      } catch (e) {
        // If scheme is missing, try prepending 'https://'
        try {
          string = `https://${string}`;
          new URL(string);
          return string;
        } catch (e) {
          return false;
        }
      }
    }
    function normalizeLocalFilePath(path) {
      let normalized = String(path || "").trim();
      if (!normalized) return "";
      normalized = normalized.replace(/^file:\/\//i, "");
      normalized = normalized.replace(/^\/+/, "");
      normalized = normalized.replace(/^root\//i, "");
      return normalized;
    }

    function looksLikeLocalFilePath(value) {
      if (!value.startsWith("file://")) return false;
      return true;
    }

    function mimeFromPath(path) {
      const name = String(path || "").toLowerCase();
      const ext = name.includes(".") ? name.slice(name.lastIndexOf(".")) : "";
      const mimeByExt = {
        ".html": "text/html",
        ".htm": "text/html",
        ".aspx": "text/html;charset=utf-8",
        ".asp": "text/html;charset=utf-8",
        ".php": "text/html;charset=utf-8",
        ".jsp": "text/html;charset=utf-8",
        ".cgi": "text/html;charset=utf-8",
        ".txt": "text/plain",
        ".md": "text/markdown",
        ".js": "application/javascript",
        ".mjs": "application/javascript",
        ".json": "application/json",
        ".css": "text/css",
        ".xml": "application/xml",
        ".svg": "image/svg+xml",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
        ".ico": "image/x-icon",
        ".pdf": "application/pdf",
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".ogg": "video/ogg",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".flac": "audio/flac",
      };
      return mimeByExt[ext] || "application/octet-stream";
    }

    function base64ToBlobUrl(base64, mimeType) {
      const raw = String(base64 || "");
      const clean = raw.replace(/\s+/g, "");
      const binary = atob(clean);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([bytes], {
        type: mimeType || "application/octet-stream",
      });
      return URL.createObjectURL(blob);
    }

    async function resolveLocalFileNavigation(inputPath, options = null) {
      const normalizedPath = normalizeLocalFilePath(inputPath);
      if (!normalizedPath) throw new Error("Missing file path");
      if (!(window.protectedGlobals.filePost)) {
        throw new Error("File service unavailable");
      }

      const response = await window.protectedGlobals.filePost({
        requestFile: true,
        requestFileName: normalizedPath,
      });

      if (!response || response.missing || response.code === "ENOENT") {
        throw new Error("File not found");
      }
      if (response.kind === "folder") {
        throw new Error("Path points to a folder");
      }

      const base64 = String(response.filecontent || "");
      const ext = normalizedPath.includes(".")
        ? normalizedPath.slice(normalizedPath.lastIndexOf(".")).toLowerCase()
        : "";

      if (ext === ".url") {
        const text = window.browserGlobals.decodeMaybeBase64(base64);
        const direct = text.trim();
        const match = text.match(/^\s*URL\s*=\s*(\S+)/im);
        const targetUrl = (match && match[1] ? match[1] : direct).trim();
        if (targetUrl && /^https?:\/\//i.test(targetUrl)) {
          return {
            iframeSrc: targetUrl,
            historyUrl: targetUrl,
            displayUrl: targetUrl,
            isLocal: false,
          };
        }
      }

      const mime = mimeFromPath(normalizedPath);
      const htmlLikeExts = new Set([
        ".html",
        ".htm",
        ".aspx",
        ".asp",
        ".php",
        ".jsp",
        ".cgi",
      ]);

      let blobUrl = "";

      blobUrl = base64ToBlobUrl(base64, mime);
      try {
        window.browserGlobals.__localFileUrlMap.set(blobUrl, normalizedPath);
        window.browserGlobals.__localFilePathToBlobMap.set(normalizedPath, blobUrl);
      } catch (e) {}
      return {
        iframeSrc: blobUrl,
        historyUrl: `file://${normalizedPath}`,
        displayUrl: `file://${normalizedPath}`,
        blobUrl,
        isLocal: true,
      };
    }

    function cleanupLocalFileNav(tab) {
      try {
        if (tab && tab.__localFileNav && tab.__localFileNav.blobUrl) {
          const mappedPath = window.browserGlobals.__localFileUrlMap.get(
            tab.__localFileNav.blobUrl,
          );
          try {
            window.browserGlobals.__localFileUrlMap.delete(tab.__localFileNav.blobUrl);
          } catch (e) {}
          try {
            if (mappedPath) {
              window.browserGlobals.__localFilePathToBlobMap.delete(mappedPath);
            }
          } catch (e) {}
          URL.revokeObjectURL(tab.__localFileNav.blobUrl);
        }
      } catch (e) {}
      if (tab) tab.__localFileNav = null;
    }

    async function openUrlInActiveTab(rawUrl, options = null) {
      const tabIndex = tabs.findIndex((t) => t.id === activeTabId);
      if (tabIndex === -1) return;
      const tab = tabs[tabIndex];
      const input = String(rawUrl || "").trim();
      if (!input) {
        window.protectedGlobals.notification("Enter a URL or file path");
        return;
      }

      if (looksLikeLocalFilePath(input)) {
        try {
          cleanupLocalFileNav(tab);
          const localNav = await resolveLocalFileNavigation(input, options);
          tab.__localFileNav = localNav;
          tab.url = localNav.historyUrl;
          tab.loadedurl = localNav.historyUrl;
          tab.title = "Loading...";
          tab.history.suppressNextRecord = false;
          if (tab.history.index < tab.history.stack.length - 1) {
            tab.history.stack = tab.history.stack.slice(
              0,
              tab.history.index + 1,
            );
          }
          tab.history.stack.push(localNav.historyUrl);
          tab.history.index = tab.history.stack.length - 1;
          tab.history.current = localNav.historyUrl;
          tab.history.currentCanonical = canonicalHistoryUrl(
            localNav.historyUrl,
          );
          tab.history.suppressNextRecord = true;
          tabs[tabIndex].iframe.src = localNav.iframeSrc;
          urlInput.value = localNav.displayUrl;
          return;
        } catch (err) {
          window.protectedGlobals.notification(
            `Unable to open file: ${String(err && err.message ? err.message : err)}`,
          );
          return;
        }
      }

      cleanupLocalFileNav(tab);

      let candidate = input;
      const urlCheck = isUrl(candidate);
      if (typeof urlCheck === "string") {
        candidate = urlCheck;
      }

      if (candidate.startsWith("javascript:")) {
        let scriptcontent = "";
        for (let i = 11; i < candidate.length; i++) {
          scriptcontent += candidate[i];
        }
        let script = document.createElement("script");
        script.textContent = scriptcontent;
        tab.iframe.contentDocument.body.appendChild(script);
        urlInput.value = window.browserGlobals.unshuffleURL(
          tab.iframe.contentWindow.location.href,
        );
        return;
      }

      let url = "";
      try {
        url = new URL(candidate).href;
      } catch (e) {
        // Edge case: allow relative entries in the URL bar.
        try {
          const currentBase = window.browserGlobals.unshuffleURL(
            tab.iframe.contentWindow.location.href,
          );
          url = new URL(candidate, currentBase).href;
        } catch (e2) {
          return;
        }
      }

      // Manual URL-bar navigations should become a fresh history point,
      // including after a prior back/forward operation.
      const canonical = canonicalHistoryUrl(url);
      const prevHistorySnapshot = {
        stack: Array.from(tab.history.stack || []),
        index: tab.history.index,
        current: tab.history.current,
        currentCanonical: tab.history.currentCanonical,
        suppressNextRecord: tab.history.suppressNextRecord,
      };
      const didCreateHistoryEntry = tab.history.currentCanonical !== canonical;

      tab.history.suppressNextRecord = false;
      if (didCreateHistoryEntry) {
        if (tab.history.index < tab.history.stack.length - 1) {
          tab.history.stack = tab.history.stack.slice(0, tab.history.index + 1);
        }
        tab.history.stack.push(url);
        tab.history.index = tab.history.stack.length - 1;
        tab.history.current = url;
        tab.history.currentCanonical = canonical;
      }
      // Prevent duplicate push when poller observes this same navigation.
      // Important: only do this when a new history entry was created, otherwise
      // stale suppression can swallow the next real navigation.
      tab.history.suppressNextRecord = didCreateHistoryEntry;

      tab.url = url;
      tab.loadedurl = url;
      tab.title = "Loading...";
      if (tabs[tabIndex].iframe) {
        createPermInput(tab.iframe, url);
        try {
          tabs[tabIndex].iframe.src = a(url, window.browserGlobals.proxyurl);
        } catch (e) {
          tab.history.stack = prevHistorySnapshot.stack;
          tab.history.index = prevHistorySnapshot.index;
          tab.history.current = prevHistorySnapshot.current;
          tab.history.currentCanonical = prevHistorySnapshot.currentCanonical;
          tab.history.suppressNextRecord =
            prevHistorySnapshot.suppressNextRecord;
          window.protectedGlobals.notification("Navigation failed");
          return;
        }
      }

      urlInput.value = url;
    }

    openBtn.addEventListener("click", () => {
      openUrlInActiveTab(urlInput.value);
    });
    urlInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") openUrlInActiveTab(urlInput.value);
    });

    if (preloadlink) {
      const id = addTab("goldenbody://newtab/", "New Tab");
      activateTab(id);
      openUrlInActiveTab(normalizePreloadLink(preloadlink));
    }

    // new tab
    newTabBtn.addEventListener("click", () => {
      const id = addTab("goldenbody://newtab/", "New Tab");
      activateTab(id);
      // urlInput.focus();
    });

    // drag to move window
    var currentX;
    var currentY;
    let active;
    (function makeDraggable() {
      let dragging = false,
        startX = 0,
        startY = 0,
        origLeft = 0,
        origTop = 0,
        targetel = null;
      let thresholdCrossed = false;
      let DRAG_THRESHOLD = window.protectedGlobals.data.DRAG_THRESHOLD || 15; // pixels required to trigger drag behavior

      top.addEventListener("pointerdown", (ev) => {
        DRAG_THRESHOLD =
          Number(window.protectedGlobals.data.DRAG_THRESHOLD) || DRAG_THRESHOLD;
        targetel = ev.target;
      });

      top.addEventListener("pointerdown", (ev) => {
        if (
          ev.target?.closest?.(".sim-tab") ||
          ev.target === newTabBtn ||
          ev.target === urlInput ||
          ev.target === openBtn ||
          targetel?.closest?.(".sim-tab")
        )
          return;
        if (active) return;
        dragging = true;
        thresholdCrossed = false;
        startX = ev.clientX;
        startY = ev.clientY;
        origLeft = root.offsetLeft;
        origTop = root.offsetTop;
        document.body.style.userSelect = "none";
        currentX = ev.clientX;
        currentY = ev.clientY;
      });

      window.addEventListener(
        "browser" + root._goldenbodyId,
        "pointermove",
        (ev) => {
          if (!dragging) return;
          if (active) return; // Don't move window while resizing
          // Calculate distance dragged from initial mousedown
          const dragDistance = Math.sqrt(
            Math.pow(ev.clientX - startX, 2) + Math.pow(ev.clientY - startY, 2),
          );

          // Only trigger the restore and drag behavior after crossing threshold
          if (!thresholdCrossed && dragDistance >= DRAG_THRESHOLD) {
            thresholdCrossed = true;
            // Restore window if it was maximized
            applyBounds(savedBounds);
            if (isMaximized) {
              restoreWindow(false);
              root.style.left = ev.clientX - root.clientWidth / 2 + "px";
              origLeft = ev.clientX - root.clientWidth / 2;
            }
          }

          if (!thresholdCrossed) return; // Don't move window until threshold crossed

          const dx = ev.clientX - startX;
          const dy = ev.clientY - startY;
          root.style.left = origLeft + dx + "px";
          root.style.top = Math.max(0, origTop + dy) + "px";
        },
      );

      window.addEventListener("browser" + root._goldenbodyId, "pointerup", () => {
        dragging = false;
        thresholdCrossed = false;
        document.body.style.userSelect = "";
        targetel = null;
      });
    })();
    let resizing;
    function resize() {
      const el = root;
      const BW = 8; // fatter edge = easier to grab
      const minW = 450,
        minH = 350;

      // ensure positioned & has top/left so we can move edges
      if (!el.style.position) el.style.position = "fixed";
      if (!el.style.top) el.style.top = "20px";
      if (!el.style.left) el.style.left = "20px";

      // state
      active = null; // {dir,sx,sy,sw,sh,sl,st}
      let dir = "";

      // helper: are we on an edge?
      const hitTest = (e) => {
        const r = el.getBoundingClientRect();
        const x = e.clientX,
          y = e.clientY;
        const onL = x >= r.left && x <= r.left + BW;
        const onR = x <= r.right && x >= r.right - BW;
        const onT = y >= r.top && y <= r.top + BW;
        const onB = y <= r.bottom && y >= r.bottom - BW;

        if (onT && onL) return "nw";
        if (onT && onR) return "ne";
        if (onB && onL) return "sw";
        if (onB && onR) return "se";
        if (onL) return "w";
        if (onR) return "e";
        if (onT) return "n";
        if (onB) return "s";
        return "";
      };
      // cursor feedback
      el.addEventListener("pointermove", (e) => {
        if (active) return; // don't flicker while resizing
        const d = hitTest(e);
        el.style.cursor =
          d === "nw" || d === "se"
            ? "nwse-resize"
            : d === "ne" || d === "sw"
              ? "nesw-resize"
              : d === "n" || d === "s"
                ? "ns-resize"
                : d === "e" || d === "w"
                  ? "ew-resize"
                  : "default";
      });

      // start resize
      el.addEventListener(
        "pointerdown",
        (e) => {
          dir = hitTest(e);
          if (!dir) return;
          resizing = true;
          e.preventDefault();
          el.setPointerCapture(e.pointerId); // <- keep events!
          const r = el.getBoundingClientRect();
          active = {
            dir,
            sx: e.clientX,
            sy: e.clientY,
            sw: r.width,
            sh: r.height,
            sl: r.left,
            st: r.top,
            startedMaximized: isMaximized,
            restoredFromMax: false,
          };

          document.body.style.userSelect = "none";
          document.body.style.cursor = getCursorForDir(dir);
          el.style.willChange = "width, height, left, top";
        },
        { passive: false },
      );
      let draginterval;
      // drag
      el.addEventListener("pointermove", (e) => {
        if (!active) return;
        if (
          active.startedMaximized &&
          !active.restoredFromMax &&
          (Math.abs(e.clientX - active.sx) > 1 ||
            Math.abs(e.clientY - active.sy) > 1)
        ) {
          applyBounds(getBounds());
          restoreWindow(false);
          console.log(savedBounds);
          const rr = el.getBoundingClientRect();
          active.sx = e.clientX;
          active.sy = e.clientY;
          active.sw = rr.width;
          active.sh = rr.height;
          active.sl = rr.left;
          active.st = rr.top;
          active.restoredFromMax = true;
        }
        const dx = e.clientX - active.sx;
        const dy = e.clientY - active.sy;

        // east / south
        if (active.dir.includes("e"))
          el.style.width = Math.max(minW, active.sw + dx) + "px";
        if (active.dir.includes("s"))
          el.style.height = Math.max(minH, active.sh + dy) + "px";

        // west / north (move edge)
        if (active.dir.includes("w")) {
          const w = Math.max(minW, active.sw - dx);
          el.style.width = w + "px";
          el.style.left = active.sl + dx + "px";
        }
        if (active.dir.includes("n")) {
          const newTop = active.st + dy;
          if (newTop >= 0) {
            const h = Math.max(minH, active.sh - dy);
            el.style.height = h + "px";
            el.style.top = newTop + "px";
          } else {
            el.style.top = "0px";
          }
        }
        savedBounds = getBounds();
      });

      // end
      function end() {
        clearInterval(draginterval);
        if (!active) return;
        active = null;
        resizing = false;
        document.body.style.userSelect = "";
        document.body.style.cursor = "";
        el.style.cursor = "default"; // <— add this
        el.style.willChange = "";
        el.querySelectorAll("iframe").forEach((f) => {
          f.style.pointerEvents = f._oldPE || "";
          delete f._oldPE;
        });
      }
      el.addEventListener("pointerup", end);
      el.addEventListener("pointercancel", end);

      // better touch behavior
      el.style.touchAction = "none";

      function getCursorForDir(d) {
        if (d === "nw" || d === "se") return "nwse-resize";
        if (d === "ne" || d === "sw") return "nesw-resize";
        if (d === "n" || d === "s") return "ns-resize";
        if (d === "e" || d === "w") return "ew-resize";
        return "default";
      }
    }
    resize();

    return {
      rootElement: root,
      iframes,
      urlInput,
      openBtn,
      activatedTab,
      addTab,
      activateTab,
      closeTab,
      openUrl: openUrlInActiveTab,
      getBounds,
      applyBounds,
      closeWindow,
      btnMax,

      get isMaximized() {
        return isMaximized;
      },
      set isMaximized(v) {
        isMaximized = !!v;
      },

      get isMinimized() {
        return isMinimized;
      },
      set isMinimized(v) {
        isMinimized = !!v;
      },

      addAndOpen: function (url) {
        const id = addTab(url);
        activateTab(id);
      },

      get tabs() {
        return tabs;
      },

      showWindow: function () {
        root.style.display = "block";
        isMinimized = false;
        window.protectedGlobals.bringToFront(root);
      },

      hideWindow: function () {
        if (!isMaximized) this.savedBounds = getBounds();
        root.style.display = "none";
        isMinimized = true;
      },
    };
  })();
  chromeWindow.closeAll = function () {
    for (const instance of [...window.browserGlobals.allBrowsers]) {
      if (instance && (instance.closeWindow)) {
        instance.closeWindow();
      }
    }
    window.browserGlobals.allBrowsers = [];
  };
  chromeWindow.hideAll = function () {
    for (const instance of window.browserGlobals.allBrowsers) {
      if (instance && (instance.hideWindow)) {
        instance.hideWindow();
      }
    }
  };
  chromeWindow.showAll = function () {
    window.browserGlobals.allBrowsers.sort(
      (a, b) => a.rootElement.style.zIndex - b.rootElement.style.zIndex,
    );
    for (const instance of window.browserGlobals.allBrowsers) {
      if (instance && (instance.showWindow)) {
        instance.showWindow();
      }
    }
  };
  chromeWindow.newWindow = function () {
    browser();
  };
  chromeWindow.showall = chromeWindow.showAll;
  chromeWindow.hideall = chromeWindow.hideAll;
  chromeWindow.closeall = chromeWindow.closeAll;
  chromeWindow.newwindow = chromeWindow.newWindow;
  window.browserGlobals.allBrowsers.push(chromeWindow); // Add to global tracking
  window.protectedGlobals.applyStyles();

  function a(url, proxyurl) {
    // dead code 4 now cuz we arent using UV
    function encodeUV(str) {
      return encodeURIComponent(
        str
          .split("")
          .map((ch, i) =>
            i % 2 ? String.fromCharCode(ch.charCodeAt(0) ^ 2) : ch,
          )
          .join(""),
      );
    }

    function encodeRammerHead(str, proxylink) {
      if (
        str.startsWith("data:") ||
        str.startsWith("blob:") ||
        str.startsWith("about:") ||
        str.startsWith("file://")
      ) {
        return str;
      }
      if (str === "goldenbody://newtab/" || str === "goldenbody://newtab") {
        return window.protectedGlobals.goldenbodywebsite + "flowerfeast.html";
      } else if (
        str === "goldenbody://app-store/" ||
        str === "goldenbody://app-store"
      ) {
        return (
          window.protectedGlobals.goldenbodywebsite +
          "singlesdaylosesingle.html"
        );
      }
      return proxylink + window.browserGlobals.id + "/" + url;
    }
    // same with this
    function encodeScramjet(url, proxylink) {
      return proxylink + "scramjet/" + url;
    }

    return encodeRammerHead(url, proxyurl);

    // => hvtrs8%2F-wuw%2Chgrm-uaps%2Ccmm
  }
};
